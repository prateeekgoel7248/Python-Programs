class Solution:
    def countVowelSubstrings(self, word: str) -> int:
        #here we are calculating all the substring from 0 to 5 length and then we are calculating the substring upto length 4 then
        #len(up to5)-len(up to 4)= we have len(5) only left
        #this is the intuition behind this question
        def countK(k):
            vowel=['a','e','i','o','u']
            cnt=0
            d=defaultdict(int)
            i=0
            for j in range(len(word)):
                if word[j] not in vowel:
                    d.clear()
                    i=j+1
                    continue
                d[word[j]]+=1
                while len(d)>k:
                    d[word[i]]-=1
                    if d[word[i]]==0:
                        d.pop(word[i])
                    i+=1
                cnt+=(j-i+1)
            return cnt
        
        return countK(5)-countK(4)
        
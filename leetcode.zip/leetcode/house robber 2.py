class Solution(object):
    def rob(self, nums):
        # if len(nums)==1:
        #     return nums[0]
        # prev1=0
        # prev2=0
        # for i in nums[1:]:
        #     prev1,prev2=prev2,max(prev2,prev1+i)
        # s=prev2
        # prev1=0
        # prev2=0
        # for i in nums[:-1]:
        #     prev1,prev2=prev2,max(prev2,prev1+i)
        # return max(prev2,s)
        if len(nums) < 2:
            return max(nums + [0])
        def regular_rob(l,r):
            last, now = 0, 0
            while l < r:
                last, now, l = now, max(last + nums[l], now), l+1
            return now
        return max(regular_rob(1, len(nums)), regular_rob(0, len(nums)-1))
        """
        :type nums: List[int]
        :rtype: int
        """
        
class Solution(object):
    def getPermutation(self, n, k):
#Approach1
        factor = factorial(n-1)
        k -= 1 
        ans = ""
        numbers_left = list(range(1,n+1))
        
        for m in range(n-1,0,-1):
            index = k // factor
            ans += str(numbers_left[index])
            numbers_left.pop(index)
            k %= factor
            factor /= m
        ans += str(numbers_left[0])
        return ans
    
#Approach 2
    
        fact=1
        nums=[]
        for i in range(1,n):
            fact*=i
            nums.append(str(i))
        nums.append(str(n))
        k-=1
        s=""
        while True:
            ind=k//fact
            s+=nums[ind]
            nums.pop(ind)
            n-=1
            if n==0:
                break
            k=k%fact
            fact//=n
        return s
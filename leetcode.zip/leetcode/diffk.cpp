int Solution::diffPossible(vector<int> &A, int B) {
    int N = A.size() - 1;
    int i = 0, j = 1;
    while(i < N && j <= N){
        if(i == j) j++;
        int diff = A[j] - A[i];
        if(diff == B) return 1;
        else if(diff < B) j++;
        else i++;
    }
    return 0;
}
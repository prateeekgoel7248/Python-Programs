# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def minCameraCover(self, root: Optional[TreeNode]) -> int:
        #0 means not monitored till now and we have to monitore that node
        #1 means monitored but not camera
        # it has camera
        def dfs(root,s):
            if not root:
                return 1
            l = dfs(root.left,s)
            r = dfs(root.right,s)
            if l==0 or r==0:
                s[0]+=1
                return 2
            elif l==2 or r==2:
                return 1
            else:
                return 0
                
            # return -1
        s=[0]
        if dfs(root,s)==0:
            s[0]+=1
        return s[0]
        
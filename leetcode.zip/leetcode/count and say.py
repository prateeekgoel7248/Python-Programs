#approach1
class Solution:
	# @param A : integer
	# @return a strings
	def countAndSay(self, n):
		if n==1:
			return "1"
		if n==2:
			return "11"
		res="11"
		for i in range(3,n+1):
			temp=""
			res=res+"&"
			count=1

			for j in range(1,len(res)):
				if res[j]!=res[j-1]:
					temp+=str(count)
					temp=temp+res[j-1]
					count=1
				else:
					count+=1
			res=temp
		return res


#approach2
class Solution:
    def countAndSay(self, n: int) -> str:
        def say(s):
            char=[]
            i=0
            while i<len(s):
                count=0
                cur=s[i]
                while i<len(s) and cur==s[i]:
                    i+=1
                    count+=1
                char.append(str(count))
                char.append(cur)
            return ''.join(char)
        if n==1:
            return "1"
        return say(self.countAndSay(n-1))
        
        
        
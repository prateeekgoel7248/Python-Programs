import java.io.*;

class Student implements Serializable {
	private int roll;
	private String name;

	public Student(int roll, String name) {
		this.roll = roll;
		this.name = name;
	} 

	public void setRoll(int roll) {
		this.roll = roll;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getRoll() {
		return this.roll;
	}
	public String getName() {
		return this.name;
	}
}

class Solution(object):
    
    def isSafe(self,row,col,board,n):
        rrow=row
        ccol=col
        
        while row>=0 and col>=0:
            if board[row][col]=='Q':
                return False
            row-=1
            col-=1
        col=ccol
        row=rrow
        while col>=0:
            if board[row][col]=='Q':
                return False
            col-=1
        row=rrow
        col=ccol
        while row<n and col>=0:
            if board[row][col]=='Q':
                return False
            row+=1
            col-=1
        return True
        
    def solve(self,col,board,ans,n):
        if col>=n:
            ans.append([''.join(row) for row in board])
            return
        for row in range(n):
            if self.isSafe(row,col,board,n):
                board[row][col]='Q'
                self.solve(col+1,board,ans,n)
                board[row][col]='.'
                
    def solveNQueens(self, n):
        ans=[]
        board=[]
        for i in range(n):
            board.append(["."]*n)
        self.solve(0,board,ans,n)
        return ans


#approach 2
#here we are using hashing 
we are taking three list which are storing that this queen appears in leftrow , lowerDiagonal and upperDiagonal or not.


# for visual representation watch take u forward n queen video last part.


class Solution(object):        
    def solve(self,col,board,ans,leftRow,upperDiagonal,lowerDiagonal,n):
        if col>=n:
            ans.append([''.join(row) for row in board])
            return
        for row in range(n):
            if leftRow[row]==0 and lowerDiagonal[row+col]==0 and upperDiagonal[n-1+col-row]==0:
                board[row][col]='Q'
                leftRow[row]=1
                upperDiagonal[n-1+col-row]=1
                lowerDiagonal[row+col]=1
                self.solve(col+1,board,ans,leftRow,upperDiagonal,lowerDiagonal,n)
                board[row][col]='.'
                leftRow[row]=0
                upperDiagonal[n-1+col-row]=0
                lowerDiagonal[row+col]=0
    def solveNQueens(self, n):
        ans=[]
        board=[]
        leftRow=[0]*n
        upperDiagonal=[0]*(2*n-1)
        lowerDiagonal = [0]*(2*n-1)
        for i in range(n):
            board.append(["."]*n)
        self.solve(0,board,ans,leftRow,upperDiagonal,lowerDiagonal,n)
        return ans

        
        # def DFS(queens, xy_dif, xy_sum):
        #     p = len(queens)
        #     if p == n:
        #         result.append(queens)
        #         return None
        #     for q in range(n):
        #         if q not in queens and p - q not in xy_dif and p + q not in xy_sum:
        #             DFS(queens + [q], xy_dif + [p - q], xy_sum + [p + q])
        # result = []
        # DFS([], [], [])
        # return [["." * i + "Q" + "." * (n - i - 1) for i in sol] for sol in result]

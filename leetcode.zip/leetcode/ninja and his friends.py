import sys
from typing import List


def maximumChocolates(n: int, m: int, grid: List[List[int]]) -> int:
    # write your code here
#     m=len(grid[0])
#     n=len(grid)
    def solve(i,j1,j2,dp):
        
        if j1<0 or j2<0 or j1>=m or j2>=m:
            return -sys.maxsize
        if i==n-1:
            if j1==j2:
                return grid[i][j1]
            else:
                return grid[i][j1]+grid[i][j2]
        if dp[i][j1][j2]!=-1:
            return dp[i][j1][j2]
        maxi=-sys.maxsize
        lis = [-1,0,1]
        for dj1 in lis:
            for dj2 in lis:
                if j1==j2:
                    maxi=max(maxi,grid[i][j1]+solve(i,j1+dj1,j2+dj2,dp))
                else:
                    maxi=max(maxi,grid[i][j1]+grid[i][j2]+solve(i,j1+dj1,j2+dj2,dp))
        dp[i][j1][j2]=maxi
        return maxi
    dp=[[[-1]*(m+1)]*(m+1)]*(n+1)
    return solve(0,0,m-1,dp)
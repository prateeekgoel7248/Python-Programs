from typing import List

def findWays(arr: List[int], k: int) -> int:
    # Write your code here.
#     def solve(ind,target,dp):
#         if target==0:
#             return 1
#         if ind==0:
#             return 1 if arr[ind]==target else 0
#         if dp[ind][target]!=-1:
#             return dp[ind][target]
#         take = 0
#         if arr[ind]<=target:
#             take = solve(ind-1,target-arr[ind],dp)
#         notTake = solve(ind-1,target,dp)
#         dp[ind][target]=take+notTake
#         return dp[ind][target]
    n=len(arr)
#     dp=[[-1 for _ in range(k+1)] for i in range(n+1)]
#     return solve(n-1,k,dp)    



# def subsetSumToK(n, k, arr):

    prev=[0]*(k+1)
    cur = [0]*(k+1)
    prev[0]=cur[0]=True
    if arr[0]<=k: prev[arr[0]]=1
    for ind in range(1,n):
        for target in range(1,k+1):
            take=0
            if arr[ind]<=target:
                take = prev[target-arr[ind]]
            ntake = prev[target]
            cur[target]=take + ntake
        prev = cur[:]
    return prev[k]
            
    
    
    
    


            
    
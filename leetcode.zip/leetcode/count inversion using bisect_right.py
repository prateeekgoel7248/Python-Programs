from os import *
from sys import *
from collections import *
from math import *
import bisect
from bisect import bisect_left,bisect_right
def getInversions(arr, n) :
    l=[]
    l.append(arr[0])
    x=0
    for i in range(1,n):
        ele = arr[i]
        ind = bisect_right(l,ele)
        if ind==0:
            x+=(len(l)-ind)
            l.insert(ind,ele)
        else:
            j=ind
            #it is for the same element like we have [5,4,3,4] so for ind =3 when we use bisect to get the 
            #index it will give us the left most index where we have to insert the element bt we have
#             while j<len(l) and l[j]==ele:
#                 j+=1
            x+=(len(l)-j)
            l.insert(j,ele)
    return x           

# Taking inpit using fast I/O.
def takeInput() :
    n = int(input())
    arr = list(map(int, stdin.readline().strip().split(" ")))
    return arr, n

# Main.
arr, n = takeInput()
print(getInversions(arr, n))
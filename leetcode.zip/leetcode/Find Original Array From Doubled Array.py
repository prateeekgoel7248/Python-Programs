class Solution:
    def findOriginalArray(self, changed: List[int]) -> List[int]:
        if len(changed)%2==1:
            return []
        changed.sort()
        d=defaultdict()
        
        d=Counter(changed)
        ans=[]
        for i in changed:
            if d[i]==0:
                continue
            d[i]-=1
            if d[2*i]>0:
                ans.append(i)
                d[2*i]-=1
            else:
                return []
        return ans
        
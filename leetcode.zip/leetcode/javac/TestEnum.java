enum Branches {

	Delhi(2),Chennai(3),Mumbai(3),Bangalore(5);
	
	private int noofOffice;
	
	private Branches(int noofOffice){
		this.noofOffice=noofOffice;
	}
	
	public int getNoofOffice(){
		return noofOffice;
	}
}
class TestEnum{
	public static void main(String[] args) {
		System.out.println(Branches.Bangalore.getNoofOffice());
	}
}

from sys import stdin

def lcs(s, t) :
    #Your code goes here
#     def solve(ind1,ind2):
#         if ind1 <0 or ind2<0:
#             return 0
#         if dp[ind1][ind2]!=-1:
#             return dp[ind1][ind2]
#         ans=0
#         if s[ind1]==t[ind2]:
#             ans= 1+solve(ind1-1,ind2-1)
#         else:
#             ans = max(solve(ind1-1,ind2),solve(ind1,ind2-1))
#         dp[ind1][ind2]=ans
#         return ans
    l = max(len(s),len(t))
#     dp=[[0 for _ in range(len(t)+1)] for i in range(len(s)+1)]
    prev = [0 for _ in range(l+1)]
    curr = prev[:]
    
    #     return solve(len(s)-1,len(t)-1)
    for ind1 in range(len(s)):
        for ind2 in range(len(t)):
            if s[ind1]==t[ind2]:
                ans= 1+prev[ind2-1]
            else:
                ans = max(prev[ind2],curr[ind2-1])
            curr[ind2]=ans
        prev = curr[:]
    return prev[len(t)-1]
            





























    


#main
s = str(stdin.readline().rstrip())
t = str(stdin.readline().rstrip())

print(lcs(s, t))
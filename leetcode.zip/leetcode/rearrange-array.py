def arrange(A):
    n = len(A)
    # we are plus the A[i] because the value of A[i] will be change so when the value change we add the A[i] value so
    # we can find the value of the previous value of that index just dry run you will get the answer lets take we did
    # for index 0 and the value if set to 19 for 0th index and we want the value which is in the 0th index in 
    # original given matrix so we will just do %n means 19%5 = 4 so we will get our value 0 4 1 0 2 2 3 1 4 3 [19, 
    # 20, 12, 1, 8] [3, 4, 2, 0, 1] 
    for i in range(n):
        # print(i, A[i])

        A[i] += A[A[i]] % n * n
    print(A)
    for i in range(n):
        A[i] = A[i] // n
    return A


A = [4, 0, 2, 1, 3]
print(arrange(A))

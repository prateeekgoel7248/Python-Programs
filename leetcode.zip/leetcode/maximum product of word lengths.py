class Solution(object):
    def maxProduct(self, words):
        n=len(words)
        length = [len(i) for i in words]
        word_int=[]
        for i in range(n):
            w=words[i]
            l=length[i]
            w_int=0
            for j in range(l):
                w_int |= 1<< (ord(w[j])-ord('a'))
                #here | means the plus of their decimal value
                #like for abcw so a=1 b=2 c=4 d=... and sum of all of them 1+2+4+4194304

            word_int.append(w_int)
            #why is this << working here 
                #-- because we have given the unique binary representation to every                       character and when we are doing or (|) operation then there bit doesn't                   change so it will remain same only the higher bit are added so 
                #if both character doesn't have any common bit means  there are no common                  character and if they have common bit means they have a (more than zero)                  common character
            #we are checking this doing the AND(&) operation.
        mx=0

        for i in range(n):
            for j in range(i+1,n):
                if word_int[i]&word_int[j]==0:
                    mx=max(mx,length[i]*length[j])
        return mx
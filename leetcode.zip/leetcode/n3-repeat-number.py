class Solution:
    # @param A : tuple of integers
    # @return an integer
    def repeatedNumber(self, A):
        n=len(A)
        count1=0
        count2=0
        import sys
        ele1=sys.maxsize
        ele2=sys.maxsize
        for i in A:
            if ele1==i:
                count1+=1
            elif ele2==i:
                count2+=1
            elif count1==0:
                count1+=1
                ele1=i
            elif count2==0:
                ele2=i
                count2+=1
            else:
                count1-=1
                count2-=1
        count1,count2=0,0
        for i in A:
            if ele1==i:
                count1+=1
            elif ele2==i:
                count2+=1
        if count1>n//3:
            return ele1
        elif count2>n//3:
            return ele2
        else:
            return -1 
class Solution(object):
    def isBipartite(self, graph):
        color =[-1 for _ in range(len(graph))]
        n=len(graph)
        for i in range(n):
            if color[i]==-1:
                if not self.bipartite(i,graph,color):
                    return False
        return True
    def bipartite(self,i,graph,color):
        
        # import queue
        # from queue import Queue
        q=[]
        q.append(i)
        
        color[i]=1
        while q:
            node=q.pop(0)
            for it in graph[node]:
                if color[it]==-1:
                    color[it]=1-color[node]
                    q.append(it)
                elif color[it]==color[node]:
                    return False
        return True
                    

        
        """
        :type graph: List[List[int]]
        :rtype: bool
        """
        
class Solution:
    def maxTaxiEarnings(self, n: int, rides: List[List[int]]) -> int:
        
        def solve(ind,dp): 
            if ind>=len(rides):
                return 0
            if dp[ind]!=-1:
                return dp[ind]
            cur = rides[ind]
            temp=0
            per =0
            nonper = solve(ind+1,dp)
            ans = len(rides)
            low = ind+1
            high = len(rides)-1
            while low<=high:
                mid=(low+high)>>1
                if rides[mid][0]>=cur[1]:
                    ans=mid
                    high=mid-1
                else:
                    low=mid+1
            per= cur[1]-cur[0]+cur[2]+solve(ans,dp)
            temp=max(per,nonper)
            dp[ind]=temp
            return temp
        rides.sort()
        dp=[-1]*(len(rides)+1)
        return solve(0,dp)
            
        
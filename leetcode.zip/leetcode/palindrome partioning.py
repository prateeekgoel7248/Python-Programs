import sys
class Solution(object):
    def partition(self, s):
        
        
        out = []
        def isPalindrome(st):
            return st == st[::-1]
        
        def dfs(curr=[], index=1):
            if index == len(s) + 1:
                out.append(list(curr))
                return
            for i in range(index, len(s)+1):
                if isPalindrome(s[index-1:i]):
                    curr.append(s[index-1:i])
                    dfs(curr, i+1)
                    curr.pop()
        dfs()
        return out
        
        
        
        
#         if len(string)==0 or len(string)==1:
#             return 0
#         # code here
#         res=[]
#         path=[]
#         def isPalindrome(st,i,j):
#             while i<j:
#                 if st[i]!=st[j]:
#                     return False
#                 i+=1
#                 j-=1
#             return True
#         def solve(s,index,res,path):
#             if index==len(s):
#                 print('p',path)
#                 res.append(path)
#                 return

#             for i in range(index,len(s)):
#                 if(isPalindrome(s,index,i)):
#                     path.append(s[index:i+1])
#                     # print(path)
#                     solve(s,i+1,res,path)
#                     path.pop()
#             return res

        
        return solve(string,0,res,path)
        # return res
public class Solution {
    public int CountHousePlacements(int n) {
        long mod=1000000007;
        long first=1;
        long second=1;
        long ans=0;
        for(int i=0;i<n;i++){
            ans=(first+second)%mod;
            second=first;
            first=ans;
        }
        return (int)((ans%mod)*(ans%mod)%mod);
        // here we are using the fibonacci pattern
        //here we require the previous and the previous-previous to get the one sided output
        
        // here we find the count for one side and then we can multiple it by thereself to get the total 
        //so total will be total=final*final
        //
        //here we got our intuition
        //let's take there are 1 house so we can get two possibility in one side
        //1 or 0
        
        // now for two hourses
        //00
        //01
        //10
        //so there are 3 possibility for one side
        //lets take three houses
        //000
        //001
        //010
        //100
        //101
        //so here 5 possibility so
        //pattern is 3+2 = 5 so we are using fibonaaci pattern here.
        
    }
}
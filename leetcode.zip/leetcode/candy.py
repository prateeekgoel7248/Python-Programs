class Solution(object):
    def candy(self, ratings):
        if len(ratings)==1:
            return 1

        else:
            candies=[1 for i in range(len(ratings))]
            for i in range(1,len(ratings)):
                if ratings[i]>ratings[i-1]:
                    candies[i]=candies[i-1]+1
                    
            for i in range(len(ratings)-2,-1,-1):
                if ratings[i]>ratings[i+1]:
                    candies[i]=max(candies[i],candies[i+1]+1)
            
            if ratings[0]>ratings[1]:
                candies[0]=max(candies[0],candies[1]+1)
            
        return sum(candies)
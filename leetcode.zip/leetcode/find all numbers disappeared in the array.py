class Solution(object):
    def findDisappearedNumbers(self, nums):
        # res=[]
        # for i in range(1,len(nums)+1):
        #     if i in nums:
        #         pass
        #     else:
        #         res.append(i)
        
        for index in range(len(nums)):
            idx = abs(nums[index]) - 1
            nums[idx] = -1 * abs(nums[idx])
        # print(nums)
        
            
        return [index + 1 for index, n in enumerate(nums) if n > 0] 
        """
        :type nums: List[int]
        :rtype: List[int]
        """
        
#in this question we are given an array and for a value of the array we give their exact value a negative value
lie for [1,4,3,1] first for the exact postion for 4 length array is [0,1,2,3] to[1,2,3,4] , now we check element value like for a[1]=4 its correct index is 3 so we can say this element is not disapperared so we assign it a negative value to index 3 and check fot other index this technique and in the last we check all positive n and give index+1 for a positive value.
class Solution(object):
    def minimumDeviation(self, nums):
        import sys
        mi=sys.maxsize
        mx=-(sys.maxsize)
        from heapq import heappush,heappop
        heap=[]
        for i in nums:
            if i%2==0:
                heappush(heap,-i)
            else:
                i=i*2
                heappush(heap,-i)
            mi=min(mi,i)
            mx=max(mx,i)
        # print(heap)
        res=mx-mi
        # print(res)
        while heap[0]%2==0:
            curr=-heap[0]
            heappop(heap)
            res=min(res,curr-mi)
            heappush(heap,-curr//2)
            mi=min(mi,curr//2)
        # print(heap)
        res=min(res,(-heap[0])-mi)
        return res
        """
        :type nums: List[int]
        :rtype: int
        """
        
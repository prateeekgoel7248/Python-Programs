import java.util.HashMap;
import java.util.Map;
import java.util.Set;
public class MapsDemo{
	public static void main(String [] args){
		HashMap<Integer,String> mapObj = new HashMap<Integer,String>();
		mapObj.put(1,"Prateek");
		mapObj.put(2,"Prerna");

		System.out.println(mapObj);
		Set<Map.Entry<Integer,String>> entrySet = mapObj.entrySet();

		for(Map.Entry<Integer,String> mE : entrySet){
			System.out.println("KEY"+mE.getKey());
			System.out.println("VALUE"+mE.getValue());
		}
	}
}
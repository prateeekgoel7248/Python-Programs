import java.io.*;
class FileDemo
{
	public static void main(String args[])
	{
		try {

			  Reader obj = new InputStreamReader(System.in);
			  
			  FileInputStream  fileReader = new FileInputStream("in.txt");
			  FileOutputStream fileWriter = new FileOutputStream("ou.txt");
			  int c = 0;
			  while((c = fileReader.read())!=-1)
			  {
				fileWriter.write(c);
				System.out.print((char)c);
			  }
		    }
		    catch(Exception e) 
		    {
			   System.out.println(e);
		    }
	}
}
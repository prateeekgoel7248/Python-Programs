class Solution:
    # @param A : tuple of integers
    # @return an integer
    def longestConsecutive(self, A):
        from collections import defaultdict
        d=defaultdict(int)
        ans=1
        count=0
        for i in A:
            count=1
            d[i]+=1
            j=i-1
            while(d[j]>0):
                count+=1
                j-=1
            j=i+1
            while(d[j]>0):
                count+=1
                j+=1
            ans=max(ans,count)
        return ans
class Solution:
    # @param A : tuple of integers
    # @return an integer
    def maximumGap(self, A):
        mx=[]
        m=A[-1]
        for i in A[::-1]:
            m=max(i,m)
            mx.append(m)
        mx=mx[::-1]
        ans=0
        i=0
        j=0
        while i<len(A) and j<len(A):
            while j<len(A) and A[i]<=mx[j]:
                ans=max(ans,j-i)
                j+=1
            i+=1
        return ans
        

            

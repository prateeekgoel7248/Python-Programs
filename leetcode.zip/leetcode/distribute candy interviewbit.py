class Solution:
    # @param A : list of integers
    # @return an integer
    def candy(self, A):
        left=[1]*len(A)
        right=[1]*len(A)
        for i in range(1,len(A)):
            if A[i-1]<A[i]:
                left[i]=left[i-1]+1

        for i in range(len(A)-2,-1,-1):
            if A[i+1]<A[i]:
                right[i]=right[i+1]+1
        res=[]
        for i in range(len(A)):
            if left[i]>=right[i]:
                res.append(left[i])
            else:
                res.append(right[i])
        return sum(res)
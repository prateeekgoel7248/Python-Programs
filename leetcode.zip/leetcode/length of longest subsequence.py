class Solution:
    # @param A : tuple of integers
    # @return an integer
    def longestSubsequenceLength(self, A):
        n=len(A)
        if n==0:
            return 0
        lis=[1 for _ in range(n)]
        lds=[1 for _ in range(n)]
        

        for i  in range(1,n):
            for j in range(i):
                if A[i]>A[j] and lis[i]<=lis[j]:
                    lis[i]=lis[j]+1
        for i in range(n-2,-1,-1):
            for j in range(n-1,i,-1):
                if A[i]>A[j] and lds[i]<=lds[j]:
                    lds[i]=lds[j]+1
        mx=lis[0]+lds[0]-1
        for i in range(1,n):
            if (lis[i]+lds[i]-1)>mx:
                mx=lis[i]+lds[i]-1
        return mx

def solvecff():
	n=int(input())
	lis=[int(i) for i in input().split()]
	mx=0
	ele=0
	from collections import defaultdict
	d=defaultdict(int)
	for i in lis:
		d[i]+=1
		if mx<d[i]:
			mx=d[i]
	temp=n-mx
	count=0
	tmp=mx
	while tmp<=temp:
		count+=1
		tmp*=2
	print(temp+count)
	





tt=int(input())
while tt:
	tt-=1
	solvecff()

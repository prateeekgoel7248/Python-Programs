class Solution(object):
    def reachableNodes(self, n, edges, restricted):
        from collections import defaultdict
        adj = defaultdict(list)
        rst = set(restricted)
        for i,j in edges:
            if i in rst or j in rst:
                continue
            adj[i].append(j)
            adj[j].append(i)
        queue=[0]
        visited={0:1}
        while queue:
            cur = queue.pop(0)
            for neighbour in adj[cur]:
                if neighbour in visited:
                    continue
                visited[neighbour]=1
                queue.append(neighbour)
        return len(visited)
                
        
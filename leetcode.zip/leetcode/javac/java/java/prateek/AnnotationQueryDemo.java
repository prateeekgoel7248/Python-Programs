



import java.lang.reflect.Method;
public class AnnotationQueryDemo{
	public static void main(String [] args) throws NoSuchMethodException,SecurityException 
	{
			Anot an = new Anot();

			Method method = an.getClass().getMethod("getAttr");
			MethodDescriptor methodDesc = method.getAnnotation(MethodDescriptor.class);
			System.out.println(methodDesc.purpose());
			System.out.println(methodDesc.version());


	}
}
class Solution(object):
    def countQuadruplets(self, nums):
        # return 2
        # We are looking for a < b < c < d that satisfies equation nums[a] + nums[b] == nums[d] - nums[c]
        
        res=0
        d=defaultdict(int)
        d[nums[0]+nums[1]]=1
        n=len(nums)
        for i in range(2,n-1):
            for j in range(i+1,n):
                res+=d[nums[j]-nums[i]]
                print("r",res)
            for j in range(i):
                #it is for updating the new values of d[i+j] 
                #like for [1,2,3,6] it will for i=2 and j=0 to 2 so 3,1 = 4 ka 0 and aise hi 3,2=5 and iska bhi 1 and phir ye loop end ho jayega 
                # i > j, i => b and j => a
                d[nums[i] + nums[j]] += 1 
                print(d[nums[i]+nums[j]])
                    # add new sums with nums[i] of left hand side to the dictionary
        
        return res                
        
                
        """
        :type nums: List[int]
        :rtype: int
        """
        
#correct solution but will give tle because of time complexity but easy to understand and we just have to memoized it.

class Solution:
    def longestIncreasingPath(self, matrix: List[List[int]]) -> int:
	    
        m, n = len(matrix), len(matrix[0])
        
        def dfs(i, j, prev):
            
            # base condition : check "out of boundaries" situation and 
            # also if "current <= previous" then these are invalid conditions. 
            if i < 0 or j < 0 or i >= m or j >= n or matrix[i][j] <= prev:
                return 0
            
            # expand and look in all four directions using simple depth first search
            left = dfs(i, j - 1, matrix[i][j])
            right = dfs(i, j + 1, matrix[i][j])
            top = dfs(i - 1, j, matrix[i][j])
            bottom = dfs(i + 1, j, matrix[i][j])
            
            # return max depth of longest increasing path and 
            # plus 1 to consider the current element.
            return max(left, right, top, bottom) + 1
             
        
        # compute the longest increasing path for each element and
        # update the max value as answer.
        ans = -1
        for i in range(m):
            for j in range(n):
                ans = max(ans, dfs(i, j, -1))
        return ans




#optimized version
#easy to understand

class Solution:
    def longestIncreasingPath(self, matrix: List[List[int]]) -> int:
        m=len(matrix)
        n=len(matrix[0])
        dp = [[-1] * n for _ in range(m)]
        
        def dfs(i,j,prev):
            if i<0 or j<0 or i>=m or j>=n or prev>=matrix[i][j]:
                return 0
            if dp[i][j]!=-1:
                return dp[i][j]
            top=dfs(i-1,j,matrix[i][j])
            right=dfs(i,j+1,matrix[i][j])
            left=dfs(i,j-1,matrix[i][j])
            bottom=dfs(i+1,j,matrix[i][j])
            
            
            dp[i][j]=max(top,right,left,bottom)+1
            return dp[i][j]
        mx=-1
        for i in range(m):
            for j in range(n):
                mx=max(mx,dfs(i,j,-1))
        return mx


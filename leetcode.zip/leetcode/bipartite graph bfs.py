bool isBipartite(int V, vector<int>adj[]){
    vector<bool> vis(V,false);
    vector<int> color(V,-1);
    queue<int> q;
    for(int j=0;j<V;++j){
        if(!vis[j]){
            int curr_color=0;
            color[0]=1;
            q.push(j);
            vis[j]=true;
            while(!q.empty()){
                int s = q.front();
                q.pop();
                curr_color=1-color[s];
                for(int i=0;i<adj[s].size();++i){
                    int v = adj[s][i];
                    if(!vis[v]){
                        vis[v]=true;
                        color[v]=curr_color;
                        q.push(v);
                    }
                    else{
                        if(color[v]!=curr_color){
                            return false;
                        }
                    }
                }
            }
        }
    }
    return true;
}
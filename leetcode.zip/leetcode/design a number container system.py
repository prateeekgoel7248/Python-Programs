from sortedcontainers import SortedList
class NumberContainers(object):

    def __init__(self):
        self.d={}
        self.s={}

    def change(self, index, number):
        if index in self.d:
            self.s[self.d[index]].remove(index)
        self.d[index]=number
        if number not in self.s:
            self.s[number]=SortedList()
        self.s[number].add(index)
        
        
            
        """
        :type index: int
        :type number: int
        :rtype: None
        """
        

    def find(self, number):
        if number in self.s and len(self.s[number])>0:
            return self.s[number][0]
        return -1
        
        """
        :type number: int
        :rtype: int
        """
        


# Your NumberContainers object will be instantiated and called as such:
# obj = NumberContainers()
# obj.change(index,number)
# param_2 = obj.find(number)
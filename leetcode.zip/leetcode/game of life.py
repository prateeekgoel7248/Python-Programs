class Solution(object):
    def gameOfLife(self, b):
        
        m, n = len(b), len(b[0])
        dirs = [[-1,-1],[-1,0],[-1,1],[0,1],[1,1],[1,0],[1,-1],[0,-1]]
        #they are just the directions written in clock wise manner 
        #easy to understand 
        for i in range(m):
            for j in range(n):
                livecount = 0
                for r, c in dirs:
                    nr, nc = i + r, j + c
                    if 0 <= nr < m and 0 <= nc < n and abs(b[nr][nc]) == 1: # originally 1's
                        livecount += 1
                if b[i][j] == 1:
                    if livecount < 2 or livecount > 3:   
                        b[i][j] = -1
                else:
                    if livecount == 3:  
                        b[i][j] = 2
        
        for i in range(m):
            for j in range(n):
                if b[i][j] == 2:    b[i][j] = 1
                elif b[i][j] == -1: b[i][j] = 0
#         def ne(board,i,j):
#             if i<0 or i>=len(board) or j<0 or j>=len(board[0]) or board[i][j]==0 or board[i][j]==3:
#                 return 0
#             else:
#                 return 1
                
#         for r in range(len(board)):
#             for c in range(len(board[0])):
#                 ln=ne(board,r-1,c-1)+ne(board,r-1,c)+ne(board,r-1,c+1)+ne(board,r,c+1)+ne(board,r+1,c+1)+ne(board,r+1,c)+ne(board,r+1,c-1)+ne(board,r,c-1)
#                 # print(ln)
#                 if board[r][c]==1:
#                     if ln<2 or ln>3:
#                         board[r][c]=2
#                     else:
#                         board[r][c]=3  
#                 else:
#                     board[r][c]=3 if ln==3 else 2
#         # print(board)
#         for r in range(len(board)):
#             for c in range(len(board[0])):
#                 if board[r][c]==3:
#                     board[r][c]=1
#                 elif board[r][c]==2:
#                     board[r][c]=0
        # print(board)
        
                
        
class Solution(object):
    def countSubstrings(self, s):
        res=0
        
        for i in range(len(s)):
            l=r=i
	# it is for the odd length palindrome , we jumped to any character and check for its left and right and check both are equal or not
            while l>=0 and r<len(s) and s[l]==s[r]:
                res+=1
                l-=1
                r+=1
            l=i
            r=i+1
# checking all the even length palindromes, we jumped to any position and take a pointer to that positon and a pointer to the next node and decrement and increment the point  and check the even length string is palindrome or not  and adding it.
            while l>=0 and r<len(s) and s[l]==s[r]:
                res+=1
                l-=1
                r+=1
        return res
                


#brute force




class Solution(object):
    def countSubstrings(self, s):
        def isPalindrome(s):
            i = 0
            j = len(s) - 1
            while i < j:
                if s[i] != s[j]:
                    return False
                i += 1
                j -= 1
            return True
        count=0
        for i in range(len(s)):
            for j in range(i,len(s)):
                if isPalindrome(s[i:j+1]):
                    # print(s[i:j+1])
                    count+=1
        return count
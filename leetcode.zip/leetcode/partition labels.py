class Solution(object):
    def partitionLabels(self, S):
        rightmost = {c:i for i, c in enumerate(S)}
        left, right = 0, 0

        result = []
        for i, letter in enumerate(S):

            right = max(right,rightmost[letter])

            if i == right:
                result += [right-left + 1]
                left = i+1

        return result

# for a string "ababcbacadefegdehijhklij"
# we will check for the occurence of an element which is last 
for ababcbacadefegdehijhklij" the partion will be ababcbaca|defegde|hijhklij
so ans will be [9,7,8]
so we will  do it using the above code.
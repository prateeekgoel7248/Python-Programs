import java.io.*;

class DataWrite {
	public static void main(String[] args) {
		Student s = new Student(1, "Prateek");
		try {
			FileOutputStream fOut = new FileOutputStream("object");
			ObjectOutputStream objOut = new ObjectOutputStream(fOut);
			objOut.writeObject(s);
		} catch(IOException ex) {
			System.out.println(ex);
		}

	}
}
class Solution:
    
    #Function to detect cycle in an undirected graph.
	def isCycle(self, V, adj):
		#Code here
		vis=[0 for _ in range(V)]
		def TF(src):
		    vis[src]=1
		    q=[]
		    q.append([src,-1])
		    while q:
		        val,par=q.pop(0)
		        for n in adj[val]:
		            if not vis[n]:
		                q.append([n,val])
		                vis[n]=1
		            elif n!=par:
		                return True
		    return False
		
		for i in range(V):
		    if not vis[i]:
		        temp = TF(i)
		        if temp:
		            return True
		        
		return False


#{ 
 # Driver Code Starts
if __name__ == '__main__':

	T=int(input())
	for i in range(T):
		V, E = map(int, input().split())
		adj = [[] for i in range(V)]
		for _ in range(E):
			u, v = map(int, input().split())
			adj[u].append(v)
			adj[v].append(u)
		obj = Solution()
		ans = obj.isCycle(V, adj)
		if(ans):
			print("1")
		else:
			print("0")

# } Driver Code Ends
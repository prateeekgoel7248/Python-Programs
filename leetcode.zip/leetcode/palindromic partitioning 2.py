from sys import stdin, setrecursionlimit
import sys
setrecursionlimit(10**6)


def palindromePartitioning(s):
    # Write your code here.
        n=len(s)
        def isPalindrome(i,j):
            while i < j:
                if s[i] != s[j]:
                    return False
                i += 1
                j -= 1
            return True

        def solve(i,dp):
            if i==n:
                return 0
            # temp=""
            if dp[i]!=-1:
                return dp[i]
            mn=sys.maxsize
            for j in range(i,n):
                if isPalindrome(i,j):
                    mn=min(mn,1+solve(j+1,dp))
            dp[i]=mn
            return mn
        dp=[-1 for _ in range(n)]
        return solve(0,dp)-1

# Main
t = int(input())
while t:
    string = list(map(str, input()))
    while(" " in string):
        string.remove(" ")
    print(palindromePartitioning(string))
    t = t-1

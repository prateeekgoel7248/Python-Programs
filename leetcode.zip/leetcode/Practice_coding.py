def isPalindrome(s):
    i = 0
    j = len(s) - 1
    while i < j:
        if s[i] != s[j]:
            return False
        i += 1
        j -= 1
    return True


def IntList():
    lis = input().split()
    lis = list(map(int, lis))
    # print(lis)
    return lis


def StrList():
    s = input()
    lis = [val for val in s]
    # print(lis)
    return lis


def FloatList():
    lis = input().split()
    lis = list(map(float, lis))
    return lis


def searchRange(nums, target):
    res = []
    ans1 = -1
    ans2 = -1

    def bs(nums, key):
        start = 0
        end = len(nums) - 1
        ans = -1
        while start <= end:
            mid = start + (end - start) // 2
            if nums[mid] == key:
                ans = mid
                end = mid - 1
            elif nums[mid] > key:
                end = mid - 1
            else:
                start = mid + 1
        return ans

    def bs1(nums, key):
        start = 0
        end = len(nums) - 1
        ans = -1
        while start <= end:
            mid = start + (end - start) // 2
            if nums[mid] == key:
                ans = mid
                start = mid + 1
            elif nums[mid] > key:
                end = mid - 1
            else:
                start = mid + 1
        return ans

    ans1 = bs(nums, target)
    ans2 = bs1(nums, target)
    res.append(ans1)
    res.append(ans2)
    return res


def dsum(n):
    s = 0
    for i in str(n):
        s += int(i)
    return s


def solveByPRateek():
    n = int(input())
    lis = IntList()
    print(len(lis))
    s=set(lis)
    print(len(s))
    print(s)
    print(len(s))


tt = int(input())
while tt:
    tt -= 1
    solveByPRateek()

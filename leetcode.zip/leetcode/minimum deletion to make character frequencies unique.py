class Solution(object):
    def minDeletions(self, s):
        f=[s.count(i) for i in set(s)]
        f.sort()
        ok=[]; c=0
        for i in f:
            if i not in ok:
                ok+=[i]
            else:
                while i in ok:
                    i-=1; c+=1
                if i: ok+=[i]
        return c
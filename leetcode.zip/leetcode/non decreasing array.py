class Solution(object):
    def checkPossibility(self, nums):
        changed=False
        for i in range(len(nums)-1):
            if nums[i]<=nums[i+1]:
                continue
            if changed:
                return False
            if i and nums[i-1]>nums[i+1]:
                nums[i+1]=nums[i]
            changed=True
        return True
                
                
        """
        :type nums: List[int]
        :rtype: bool
        """
        
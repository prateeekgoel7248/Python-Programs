class Solution(object):
    def canJump(self, nums):
        # if len(nums)<=1:
        #     return True
        # elif nums[0]=
        reachable=0
        for i in range(len(nums)):
            if reachable<i:
                return False
            reachable=max(reachable,i+nums[i])
            if reachable>=len(nums)-1:
                return True
            
        return True
            
        """
        :type nums: List[int]
        :rtype: bool
        """
        
class Solution(object):
    def minDominoRotations(self, tops, bottoms):
        import sys
        res=sys.maxsize
        n=len(tops)
        for i in range(1,7):
            totalIs=0
            cnt1=0
            cnt2=0
            for j in range(n):
                if tops[j]==i or bottoms[j]==i:
                    totalIs+=1
                    if tops[j]!=i:
                        cnt1+=1
                    if bottoms[j]!=i:
                        cnt2+=1
            if totalIs==n:
                res=min(res,min(cnt1,cnt2))
        if res==sys.maxsize:
            return -1
        else:
            return res
        """
        :type tops: List[int]
        :type bottoms: List[int]
        :rtype: int
        """
        
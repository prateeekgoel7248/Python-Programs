class Solution(object):
    def coinChange(self, coins, amount):
        n=len(coins)
        dp=[[(10**4) for _ in range(amount+1)] for i in range(n+1)]
        for i in range(n+1):
            for j in range(amount+1):
                if j==0:
                    dp[i][j]=0
                elif i==0:
                    dp[i][j]=10**5
                elif coins[i-1]>j:
                    dp[i][j]=dp[i-1][j]
                else:
                    dp[i][j]=min(1+dp[i][j-coins[i-1]],dp[i-1][j])
        return dp[n][amount] if dp[n][amount]<10**4 else -1
                    
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        """
        :type coins: List[int]
        :type amount: int
        :rtype: int
        """
        
def dfs(node,parent):
    vis[node]=True
    for neighbour in adj[node]:
        if not vis[neighbour]:
            if dfs(neighbour,node):
                return True
        elif neighbour != parent:
            return True
    return False
    
v,e = map(int,input().split())
from collections import defaultdict
adj=defaultdict(list)
vis=[False for _ in range(v)]
for i in range(e):
    a,b = map(int,input().split())
    adj[a].append(b)
    adj[b].append(a)
print(dfs(0,-1))
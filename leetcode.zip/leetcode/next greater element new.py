class Solution(object):
    def nextGreaterElement(self, nums1, nums2):
        d={}
        stack=[]
        for i in nums2[::-1]:
            while stack and stack[-1]<i:
                stack.pop()
            if not stack:
                d[i]=-1
            else:
                d[i]=stack[-1]
            stack.append(i)
        
        res=[]
        for i in nums1:
            res.append(d[i])
        return res
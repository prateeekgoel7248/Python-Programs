# Definition for a binary tree node.
# class TreeNode(object):
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution(object):
    def maxPathSum(self, root):
        maxSum=[root.val]
        def dfs(node):
            if not node:
                return 0
            left_path=max(dfs(node.left),0)
            right_path=max(dfs(node.right),0)
            maxSum[0]=max(maxSum[0],node.val+left_path+right_path)
            return node.val+max(left_path,right_path)
        dfs(root)
        return maxSum[0]
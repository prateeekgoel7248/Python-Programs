class Solution:
    # @param A : string
    # @param B : string
    # @param C : string
    # @return an integer
    def isInterleave(self, s1, s2, s3):
        n1, n2, n3 = len(s1), len(s2), len(s3)
        if n1+n2 != n3: return 0
        mem = {}
        
        def dp(i1,i2):
            if i1==n1 and i2==n2: return 1
            if i1==n1: 
                
                return s2[i2:]==s3[i1+i2:]
            
            if i2==n2:
                return s1[i1:]==s3[i1+i2:]
            
            
            if (i1,i2) in mem: return mem[(i1,i2)]
            
            ans = False
            if s1[i1]==s3[i1+i2]:
                ans |= dp(i1+1, i2)
            # if ans is previously true then there is no need to check that again    
            if not ans and s2[i2]==s3[i1+i2]:
                ans |= dp(i1, i2+1)
                
            mem[(i1,i2)] = ans
            return ans
        
        return 1 if dp(0, 0) else 0
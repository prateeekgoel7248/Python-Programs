class Solution:
    def minDays(self, b: List[int], m: int, k: int) -> int:
        #k is the number of flowers which we needed
        #m is the banquet we have to make
        #if not possible return -1

#just an easy appoach and similar to the minimum number of book pages by AADITYA VERMA
        res=-1
        start=0
        end=max(b)
        def valid(day:int):
            total=0
            count=0
            for d in b:
                if d>day:
                    count+=total//k
                    total=0
                else:
                    total+=1
            count+=total//k
            return count>=m
        while start<=end:
            mid=start+(end-start)//2
            if valid(mid):
                res=mid
                end=mid-1
            else:
                start=mid+1
        return res
                    
        
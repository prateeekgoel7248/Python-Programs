class Solution:
    #Function to check whether all nodes of a tree have the value 
    #equal to the sum of their child nodes.
    def solve(self,root):
        if not root:
            return True
        s=0
        if root.left:
            s+=root.left.data
        if root.right:
            s+=root.right.data
        tmp=True
        if root.left or root.right:
            tmp = root.data==s
        
        flag = tmp and self.solve(root.left) and self.solve(root.right)
        # print(flag)
        return flag
            
    def isSumProperty(self, root):
        return 1 if self.solve(root) else 0
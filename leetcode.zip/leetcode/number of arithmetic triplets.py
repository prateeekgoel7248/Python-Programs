class Solution(object):
    def arithmeticTriplets(self, s, diff):
        ret=0
        for i in s: 
            ret+= (s.count(i-diff) and s.count(i+diff))
        return ret
        
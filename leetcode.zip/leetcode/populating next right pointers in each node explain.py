"""
# Definition for a Node.
class Node:
    def __init__(self, val: int = 0, left: 'Node' = None, right: 'Node' = None, next: 'Node' = None):
        self.val = val
        self.left = left
        self.right = right	curr = root
        while curr and curr.left:
            n=curr
            while True:
                n.left.next=n.right
                if n.next==None:
                    break
                n.right.next=n.next.left
                n=n.next
            curr=curr.left
        return root
        self.next = next
"""

class Solution:
    def connect(self, root: 'Optional[Node]') -> 'Optional[Node]':
        curr = root
        while curr and curr.left:
            n=curr
            #n is pointing to the current value
            while True:
                n.left.next=n.right
                #here we are making the left ->right connection
                if n.next==None:
                    #we are checking that is there any other next for which we have to connect left to right
                    break
                n.right.next=n.next.left
                #it is for the next node  here we are doing like make a connection between 5 and 6(see the example shown there).
                n=n.next
                #here we are updating the current node
            curr=curr.left
        return root
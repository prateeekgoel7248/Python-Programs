class Solution:
    # @param A : tuple of integers
    # @return an integer
    def maxSubArray(self, A):
        mx=A[0]
        s=0
        for i in range(len(A)):
            s+=A[i]
            mx=max(mx,s)
            if s<0:
                s=0
        return mx


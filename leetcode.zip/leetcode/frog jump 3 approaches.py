from typing import *
import sys

  
def frogJump(n: int, heights: List[int]) -> int:

    # Write your code here.
#     def solve(n,dp):
#         if n==0:
#             return 0
#         if dp[n]!=-1:
#             return dp[n]
#         second=sys.maxsize
#         first = abs(heights[n-1]-heights[n])+solve(n-1,dp)
#         if n>1:
#             second = abs(heights[n-2]-heights[n])+solve(n-2,dp)
#         dp[n]=min(first,second)
#         return dp[n]
#     dp=[0 for _ in range(n)]
    prev = 0
    sprev =0
    for i in range(1,n):
        first = abs(heights[i-1]-heights[i])+prev
        second=sys.maxsize
        if i>1:
            second = abs(heights[i-2]-heights[i])+sprev
        sprev = prev
        prev = min(first,second)
        
    return prev
    

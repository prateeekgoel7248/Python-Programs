def firstOccurance(numbers, length, searchnum):
    answer = -1  #If the number is not in the list it will return -1
    start = 0    #Starting point of the list
    end = length - 1     #Ending point of the list
    
    while start <= end:
        middle = (start + end)//2    #Finding the middle point of the list
        
        if numbers[middle] == searchnum:
            answer = middle
            end = middle - 1
        elif numbers[middle] > searchnum:
            end = middle - 1    
        else:
            start = middle + 1
    
    return answer


nums = [1, 1, 2, 2, 2, 3, 5, 5, 6, 6, 6, 7, 8]
tl = len(nums)   #Total Length of the List
sn = 4   #The number which you want to search

ans = firstOccurance(nums, tl, sn)
print(ans)

class Solution(object):
    def nextGreaterElement(self, nums1, nums2):
        greater_map = {x : -1 for x in nums1} 
        stack = []
		
        for num in nums2:
            while stack and stack[-1] < num:
                prev_num = stack.pop()
                if prev_num in greater_map:
                    greater_map[prev_num] = num
                
            stack.append(num)
            # print(stack)
            
        return [greater_map[x] for x in nums1]
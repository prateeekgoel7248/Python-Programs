#Approach1


"""
# Definition for a Node.
class Node:
    def __init__(self, val: int = 0, left: 'Node' = None, right: 'Node' = None, next: 'Node' = None):
        self.val = val
        self.left = left
        self.right = right
        self.next = next
"""
#in this we are traversing level wise but from right to left and first when we got the righest element that means there will be no next for that element so we give it next to None and then add adding the right and left element of that node and 
continue the process

# just a simple approach read and understand
class Solution:
    def connect(self, root: 'Node') -> 'Node':
        q=deque()
        q.append(root)
        while q:
            # print(q)
            prev = None
            for i in range(len(q)):
                top=q.popleft()
                if top:
                    top.next=prev
                    prev=top
                    if top.right:
                        q.append(top.right)
                    if top.left:
                        q.append(top.left)
        return root




#approach 2 with constant space
#for constant space we are taking the current next for the next traversal of the node becuase we know the traversal for the next level will start from the left most element's left so we take the record of that in the dummy.
"""
# Definition for a Node.
class Node:
    def __init__(self, val: int = 0, left: 'Node' = None, right: 'Node' = None, next: 'Node' = None):
        self.val = val
        self.left = left
        self.right = right
        self.next = next
"""

class Solution:
    def connect(self, root: 'Node') -> 'Node':
        if not root:
            return None
        curr=root
        dummy=Node(-999)        
        head=root        
        while head:
            curr=head # initialize current level's head
            prev=dummy
			# iterate through the linked-list of the current level and connect all the siblings in the next level
            while curr: 
                if curr.left:
                    prev.next=curr.left
                    prev=prev.next
                if curr.right:
                    prev.next=curr.right
                    prev=prev.next                                                
                curr=curr.next
            head=dummy.next # update head to the linked list of next level
            dummy.next=None # reset dummy node
            #head now poiting to the next traversal first node
            #it is also a simple approach
        return root
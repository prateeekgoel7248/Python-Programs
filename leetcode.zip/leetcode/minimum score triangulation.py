class Solution(object):
    def minScoreTriangulation(self, arr):
        n=len(arr)
        dp=[[0 for _ in range(n+1)] for i in range(n+1)]

        for i in range(n-1,0,-1):
            for j in range(i+1,n):
                if i==j:
                    dp[i][j]=0
                else:
                    mn=sys.maxsize
                    for k in range(i,j):
                        steps = (arr[i-1]*arr[k]*arr[j])+dp[i][k]+dp[k+1][j]
                        mn = min(mn,steps)
                    dp[i][j]=mn
        return dp[1][n-1]
    
    
    
    
    
    
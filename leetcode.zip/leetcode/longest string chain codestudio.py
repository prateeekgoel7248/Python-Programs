class Solution(object):
    def longestStrChain(self, words):
        def check(s1,s2):
            l1 = len(s1)
            l2 = len(s2)
            if l1!=l2+1:
                return False
            first =0
            second=0
            while first <l1:
                if second<l2 and s1[first]==s2[second]:
                    first+=1
                    second+=1
                else:
                    first+=1
            return  first==l1 and second == l2
            
        words.sort(key=lambda x:len(x))
        n=len(words)
        mx=-1
        dp=[1 for _  in range(n+1)]
        for i in range(n):
            for prev in range(i):
                if check(words[i],words[prev]) and 1+dp[prev]>dp[i]:
                    dp[i]=dp[prev]+1
            if dp[i]>mx:
                mx=dp[i]
        return mx
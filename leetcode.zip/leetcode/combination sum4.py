class Solution(object):
    def combinationSum4(self, nums, target):
        def f(target,arr):
            if target==0:
                dp[0]=1
                # print(1)
                return 1
            if dp[target]!=-1:
                return dp[target]
            cnt=0
            for i in nums:
                if i<=target:
                    cnt+=f(target-i,arr)
                else:
                    break
            dp[target]=cnt
            return dp[target]
            # return res
        dp=[-1 for _ in range(target+1)]
        nums.sort()
        f(target,nums)
        return dp[target]
        
class Solution:
    # @param A : list of integers
    # @param B : integer
    # @return an integer
    def solve(self, nums, K):
        # def get_max_sum(nums,K):
        maxsum = sum(nums[:K])
        currsum = maxsum 
        k = K-1
        while(k>=0):
            currsum -= nums[k]
            k -=1
            currsum += nums[-(K-k-1)]
            maxsum = max(currsum,maxsum)
        return maxsum

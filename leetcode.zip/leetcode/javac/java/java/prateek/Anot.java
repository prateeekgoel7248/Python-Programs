// import java.util.*;

public class Anot{
	// public static void main(String[] args){
			int attr;
			@MethodDescriptor(purpose="THis is a getter method",version=1)
			public int getAttr(){
				return attr;
			}

			@MethodDescriptor(purpose="THis is a setter method",version=0)
			public void setAttr(int attr){
				this.attr=attr;
			}
	// }
}
class Solution(object):
    def findDuplicate(self, nums):
        if len(nums)<=2:
            return nums[0]
        # start=0
        # end=len(nums)-1
        # while start<end:
        #     if start !=end and nums[start]==nums[end]:
        #         return nums[start]
        # low = 0
        # high = len(nums) - 1
        # mid = (high + low) / 2
        # while high - low > 1:
        #     count = 0
        #     for k in nums:
        #         if mid < k <= high:
        #             count += 1
        #     if count > high - mid:
        #         low = mid
        #     else:
        #         high = mid
        #     mid = (high + low) / 2
        # return high
        
        slow=nums[0]
        fast=nums[0]
        slow=nums[slow]
        fast=nums[nums[fast]]
        while slow!=fast:
            slow=nums[slow]
            fast=nums[nums[fast]]
        fast=nums[0]
        while slow!=fast:
            slow=nums[slow]
            fast=nums[fast]
        return slow
        
        
        
        """
        :type nums: List[int]
        :rtype: int
        """
        
class Solution:
    def minOperations(self, nums: List[int]) -> int:
        mn=len(nums)
        n=len(nums)
        # nums.sort()
        nums = list(set(nums))
        nums.sort()
        j=0
        for i in range(len(nums)):
            while j<len(nums) and nums[j]-nums[i]<=n-1:
                j+=1
            mn=min(mn,n-j+i)
        return mn
class Solution(object):
    def solve(self,strs,m,n,dp,count,index):
        if (m+n==0) or index>=len(strs):
            return 0
        
        cnt= count[index]
        # print(dp[m][n][index])
        if dp[m][n][index]!=-1:
            return dp[m][n][index]
        store=0
        if m>=cnt[0] and n>=cnt[1]:
            store = 1+self.solve(strs,m-cnt[0],n-cnt[1],dp,count,index+1)
        skip=self.solve(strs,m,n,dp,count,index+1)
        dp[m][n][index]=max(store,skip)
        return dp[m][n][index]
            
        
    def findMaxForm(self, strs, m, n):
        l=len(strs)
        dp=[[[-1 for _ in range(l+1)] for i in range(n+1)]for k in range(m+1)]
        count=[]
        for i in strs:
            temp=[0,0]
            for j in i:
                temp[int(j)]+=1
            count.append(temp)
        from collections import defaultdict
        d=defaultdict(int)
        return self.solve(strs,m,n,dp,count,0)
        """
        :type strs: List[str]
        :type m: int
        :type n: int
        :rtype: int
        """
        
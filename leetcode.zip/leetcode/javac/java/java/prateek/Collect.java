import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.ListIterator;
class collect{
	public static void main(String [] args){
		ArrayList<String> instList = new ArrayList<String>();
		instList.add("Prateek");
		instList.add("Goel");
		instList.add("Prachi");
		instList.add("Prerna");
		instList.add("Tushar");
		instList.add("Yash");
		// instList.add("Prateek");
		// instList.add("Goel");
		System.out.println(instList);

		// ArrayList<String> arr = new ArrayList<String>();
		// arr.addAll(instList);
		// System.out.println(arr);
		// System.out.println(arr.size());
		// String[] st = new String[6];
		// String[] ins = arr.toArray(st);
		// for(String a:ins){
		// 	System.out.println(a);
		// }


		// System.out.println(instList.get(1));
		HashSet <Integer> hash = new HashSet<Integer>();
		hash.add(1);
		hash.add(2);
		hash.add(3);
		System.out.println(hash);
		ListIterator<String> itr = instList.iterator();
		while(itr.hasNext()){
			System.out.println(itr.next());
		}
		while(itr.hasPrevious()){
			System.out.println(itr.next());
		}
	}
	
}
#striver

#memoization
import sys
class Solution(object):
    def solve(self,i,j,cuts,dp):
        if i>j:
            return 0
        if dp[i][j]!=-1:
            return dp[i][j]
        mini=sys.maxsize
        for ind in range(i,j+1):
            temp=(cuts[j+1]-cuts[i-1])+self.solve(i,ind-1,cuts,dp)+self.solve(ind+1,j,cuts,dp)
            mini=min(temp,mini)
        dp[i][j]=mini
        return mini
        
        
    def minCost(self, n, cuts):
        c=len(cuts)
        dp=[[-1 for _ in range(c+1)] for i in range(c+1)]
        cuts.append(n)
        cuts.insert(0,0)
        cuts.sort()
        return self.solve(1,c,cuts,dp)
        """
        :type n: int
        :type cuts: List[int]
        :rtype: int
        """
        

#tabulation - bottom up dp
import sys
class Solution(object):
    def solve(self,i,j,cuts,dp):
        if i>j:
            return 0
        if dp[i][j]!=-1:
            return dp[i][j]
        mini=sys.maxsize
        for ind in range(i,j+1):
            temp=(cuts[j+1]-cuts[i-1])+self.solve(i,ind-1,cuts,dp)+self.solve(ind+1,j,cuts,dp)
            mini=min(temp,mini)
        dp[i][j]=mini
        return mini
        
        
    def minCost(self, n, cuts):
        c=len(cuts)
        dp=[[0 for _ in range(c+2)] for i in range(c+2)]
        cuts.append(n)
        cuts.insert(0,0)
        cuts.sort()
        
        for i in range(c,0,-1):
            for j in range(1,c+1):
                if i>j: continue
                mini=sys.maxsize
                for ind in range(i,j+1):
                    temp=(cuts[j+1]-cuts[i-1])+dp[i][ind-1]+dp[ind+1][j]
                    mini=min(temp,mini)
                dp[i][j]=mini
                # return mini
        
        return dp[1][c]
                
            
    
        # return self.solve(1,c,cuts,dp)
        """
        :type n: int
        :type cuts: List[int]
        :rtype: int
        """
        
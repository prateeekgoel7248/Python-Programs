class Solution:
    def numberOfArrays(self, differences: List[int], lower: int, upper: int) -> int:
        #Explanation on bro coders
        #
        # Lets take the example differences = [1,-3,4], lower = 1, upper = 6
        so we have to make a  4 length array 
        
        so lets take the first element of the array is a so
        array will be  = [a, a+1,a-2,a+2] so array will be like this and we have given lower and upper so we will take maximum and minimum element of our arrray
        minimum  -> a-2>=1 and maximum -> a+2<=6 
        after calculation a = [3,4] so our a will be 3 or 4 so there exist two answers.
        #
        
        
        mx=0
        mn=0
        s=0
        for i in differences:
            s+=i
            mn=min(mn,s)
            mx=max(mx,s)
        p = upper-mx
        l = lower - mn
        return p-l+1 if p-l+1>0 else 0
        
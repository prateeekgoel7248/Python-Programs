class Solution(object):
    def maximalSquare(self, matrix):
        dp=[[0 for _ in range(len(matrix[0])+1)] for i in range(len(matrix)+1)]
        import sys
        l=0
        for i in range(1,len(matrix)+1):
            for j in range(1,len(matrix[0])+1):
                if matrix[i-1][j-1]=='1':
                    dp[i][j]=1+min(dp[i-1][j],dp[i-1][j-1],dp[i][j-1])
                    l=max(l,dp[i][j])
                else:
                    dp[i][j]=0
        # print(dp)
        return pow(l,2)
                              
        """
        :type matrix: List[List[str]]
        :rtype: int
        """
        
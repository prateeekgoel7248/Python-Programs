class Solution:
    def countNegatives(self, grid: List[List[int]]) -> int:
        answer = 0
    
        for i in range(len(grid)):
            
            if grid[i][0] < 0 : answer += len(grid[0])
            elif grid[i][-1] < 0 :
                
                l = 0
                r = len(grid[0]) - 1
                while l <= r :
                    m = (l+r)>>1
                    if grid[i][m] >= 0 : l = m + 1
                    else               : r = m - 1
    
                answer += len(grid[0]) - l

        return answer
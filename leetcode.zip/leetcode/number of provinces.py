def dfs(node):
            if not visited[node]:
                visited[node]=True
                for i in range(len(isConnected[node-1])):
                    if isConnected[node-1][i]==1:
                        dfs(i+1)
        visited=[False for _ in range(len(isConnected)+1)]
        cnt=0
        for i in range(1,len(isConnected)+1):
            if not visited[i]:
                dfs(i)
                cnt+=1
        return cnt
class Solution(object):
    def fourSum(self, nums, target):
        res=[]
        k=len(nums)-2
        nums=sorted(nums)
        print(nums)
        for i in range(len(nums)):
            for j in range(i+1,len(nums)):
                l=len(nums)-1
                k=j+1
                while (k<l):
                    # for m in range(k+1,len(nums)):
                    data = nums[i]+nums[j]+nums[k]+nums[l]
                    if data==target:
                        if sorted([nums[i],nums[j],nums[k],nums[l]]) not in res:
                            res.append(([nums[i],nums[j],nums[k],nums[l]]))
                        l-=1
                    elif data<target:
                        k+=1
                    else:
                        l-=1
                        
                        
        return res
        """
        :type nums: List[int]
        :type target: int
        :rtype: List[List[int]]
        """
        
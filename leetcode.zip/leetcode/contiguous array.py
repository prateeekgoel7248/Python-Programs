class Solution(object):
    def findMaxLength(self, nums):
        n = len(nums)
        
        d = dict()
        d[0] = -1
        pre_sum, ans = 0, 0
        for i in range(n):
            pre_sum += 1 if nums[i] else -1
            if pre_sum in d:
                ans = max(ans, i - d[pre_sum])
            else:
                d[pre_sum] = i
        
        return ans
            
        # return 3
        """
        :type nums: List[int]
        :rtype: int
        """
        
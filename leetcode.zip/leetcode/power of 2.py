class Solution:
    # @param A : string
    # @return an integer
    def power(self, A):
        A=int(A)
        num=2
        while num!=A and num<A:
            num*=2
        return 1 if num==A else 0
#1-Memoization

from typing import *

  
def ninjaTraining(n: int, points: List[List[int]]) -> int:

    # Write your code here.
    def solve(day,task,dp):
        if day==0:
            mx=0
            for i in range(3):
                if i!=task:
                    mx=max(mx,points[day][i])
            return mx
        if dp[day][task]!=-1:
            return dp[day][task]
        mx=0
        for i in range(3):
            if i != task:
                mx= max(mx,points[day][i]+solve(day-1,i,dp))
        dp[day][task]=mx
        return mx
    dp=[[-1]*4 for _ in range(n+1)]
    return solve(n-1,3,dp)


#2-Tabulation 

from typing import *

  
def ninjaTraining(n: int, points: List[List[int]]) -> int:

    dp=[[0]*4 for _ in range(n+1)]
#     return solve(n-1,3,dp)
    dp[0][0]=max(points[0][1],points[0][2])
    dp[0][1]=max(points[0][0],points[0][2])
    dp[0][2]=max(points[0][0],points[0][1])
    dp[0][3]=max(dp[0])
    for day in range(1,n):
        for task in range(4):
            mx=0
            for i in range(3):
                if i != task:
                    mx= max(mx,points[day][i]+dp[day-1][i])
            dp[day][task]=mx
    return dp[n-1][3]


#3- Space Optimization

def ninjaTraining(n: int, points: List[List[int]]) -> int:

#     dp=[[0]*4 for _ in range(n+1)]
    prev=[0]*4
    curr = [0]*4
#     return solve(n-1,3,dp)
    prev[0]=max(points[0][1],points[0][2])
    prev[1]=max(points[0][0],points[0][2])
    prev[2]=max(points[0][0],points[0][1])
    prev[3]=max(prev)
    for day in range(1,n):
        for task in range(4):
            mx=0
            for i in range(3):
                if i != task:
                     curr[task]= max( curr[task],points[day][i]+prev[i])
        prev = curr[:]

    return prev[3]
class Solution(object):
    def diStringMatch(self, s):
        mx=len(s)
        mn=0
        res=[]
        for i in s:
            if i=='I':
                res.append(mn)
                mn+=1
            else:
                res.append(mx)
                mx-=1
        if s[-1]=='I':
            res.append(mn)
        else:
            res.append(mx)
        return res
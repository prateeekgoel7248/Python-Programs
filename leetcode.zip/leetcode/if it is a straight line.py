class Solution(object):
    def checkStraightLine(self, coordinates):
        x0, y0, x1, y1 = coordinates[0][0],coordinates[0][1], coordinates[1][0], coordinates[1][1]
        dx, dy = x1- x0, y1 - y0
        return all((x - x0) * dy == (y - y0) * dx for x, y in coordinates)
        # if len(coordinate)<=2:
        #     return True
        # m=(coordinate[1][1]-coordinate[0][1])/(coordinate[1][0]-coordinate[0][0])
        # for i in range(1,len(coordinate)-1):
        #     temp = (coordinate[i+1][1]-coordinate[i][1])/(coordinate[i+1][0]-coordinate[i][0])
        #     if temp!=m:
        #         return False
        # return True
        """
        :type coordinates: List[List[int]]
        :rtype: bool
        """
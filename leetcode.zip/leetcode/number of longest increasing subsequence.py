class Solution(object):
    def findNumberOfLIS(self, nums):
        n=len(nums)
        dp=[1]*(n)
        cnt=[1]*n
        mx=1
        for i in range(n):
            for prev in range(i):
                if nums[prev]<nums[i] and 1+dp[prev]>dp[i]:
                    dp[i]=1+dp[prev]
                    cnt[i]=cnt[prev]
                elif nums[prev]<nums[i] and 1+dp[prev]==dp[i]:
                    cnt[i]+=cnt[prev]
            mx=max(mx,dp[i])
        ans=0
        for i in range(n):
            if dp[i]==mx:
                ans+=cnt[i]
        return ans
class FreqStack(object):
    
#     def __init__(self):
#         self.stks = []
#         self.freq = defaultdict(int)
        
#     def push(self, val):
#         self.freq[val] += 1
#         if self.freq[val] > len(self.stks):
#             self.stks.append([val])
#         else:
#             self.stks[self.freq[val]-1].append(val)
            
#     def pop(self):
#         while not self.stks[-1]:
#             self.stks.pop()
#         val = self.stks[-1].pop()
#         self.freq[val] -= 1
#         return val
    
#     def __init__(self):
#         self.freq = collections.Counter()
#         self.m = collections.defaultdict(list)
#         self.maxf = 0

#     def push(self, x):
#         freq, m = self.freq, self.m
#         freq[x] += 1
#         self.maxf = max(self.maxf, freq[x])
#         m[freq[x]].append(x)
#         print(m)

#     def pop(self):
#         freq, m, maxf = self.freq, self.m, self.maxf
#         x = m[maxf].pop()
#         if not m[maxf]: self.maxf = maxf - 1
#         freq[x] -= 1
#         return x

#     def __init__(self):
#         self.heap = []
#         self.m = collections.defaultdict(int)
#         self.counter = 0
        
#     def push(self, x):
#         self.m[x]+=1
#         heapq.heappush(self.heap,(-self.m[x], -self.counter, x))
#         self.counter+=1
    
#     def pop(self):
#         toBeRemoved = heapq.heappop(self.heap)
#         self.m[toBeRemoved[2]]-=1
#         return toBeRemoved[2]
        


# Your FreqStack object will be instantiated and called as such:
# obj = FreqStack()
# obj.push(val)
# param_2 = obj.pop()
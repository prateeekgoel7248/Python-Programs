class Solution(object):
    def canFinish(self, numCourses, prerequisites):
        
        
        
        """
            #using the basic dfs cycle detection in directed graph
            vis=[False for _ in range(numCourses)]
            pathVis = vis[:]
            adj = defaultdict(list)
            def dfsCycle(node):
                vis[node]=True
                pathVis[node]=True
                for n in adj[node]:
                    if not vis[n]:
                        if dfsCycle(n):
                            return True
                    elif pathVis[n]:
                        return True


                pathVis[node]=False
                return False

            for i,j in prerequisites:
                adj[j].append(i)
            for i in range(numCourses):
                if not vis[i]:
                    if dfsCycle(i):
                        # vis[i]=True
                        return False
            return True
        """
class Solution(object):
    
    def f(self,ind,arr,target,ds,ans):
        if target==0:
            ans.append(ds)
            return 
        for i in range(ind,len(arr)):
            if i>ind and arr[i]==arr[i-1]:
                continue
            if arr[i]>target:
                break
            self.f(i+1,arr,target-arr[i],ds+[arr[i]],ans)

    def combinationSum2(self, candidates, target):
        candidates.sort()
        ans=[]
        ds=[]
        self.f(0,candidates,target,ds,ans)
        return ans
class Solution:
    def minimumTime(self, s):
        def minSum(nums):
            dp = [0]*len(nums)
            dp[0] = nums[0]
            for i in range(1, len(nums)):
                dp[i] = min(nums[i], nums[i] + dp[i-1])
            return min(0, min(dp))

        n = len(s)
        s1 = [1 if i == "1" else -1 for i in s]
        score = minSum(s1)
       
        return n + score





Actually this problem is about maximum sum on subarray (or minimum, which is equivalent), let us show this. The optimal strategy will be:

Take some elements from the left
Take some elements from the right
Take the rest elements from the middle.
Now, the question is how to choose left and right parts, we can have potentially O(n^2) options and we can not check them all. Let us calculate how much we paid:

|..left..|..middle..|..right..|

For left and right we paid just their lengths. For middle we pay twice number of ones se have inside, so we have: len(left) + 2* count(middle, 1) + len(right) = len(left) + len(middle) + len(right) + 2*count(middle, 1) - len(middle) = n + count(middle, 1) - count(middle, 0).

So, in fact what we need to found is the subarray with the smallest count(middle, 1) - count(middle, 0) value. If we now replace all 0 with -1, it is the same as found the subarray with the smallest sum! And we can use classical dp solution for problem 53. Maximum Subarray. Do not forgot about empty array case, it costs me 5min penalty on the contest.

Complexity
It is O(n) for time and space.
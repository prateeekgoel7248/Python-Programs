class Solution(object):
    def solve(self,index,target,cand,ans,ds):
        if index==len(cand):
            if target==0:
                ds.append(ans)
            return
        if cand[index]<=target:
            self.solve(index,target-cand[index],cand,ans+[cand[index]],ds)
        self.solve(index+1,target,cand,ans,ds)
        
    def combinationSum(self, candidates, target):
        ans=[]
        ds=[]
        self.solve(0,target,candidates,ans,ds)
        return ds
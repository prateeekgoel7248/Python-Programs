class Solution:
    def minWindow(self, s: str, t: str) -> str:
        l=r=0
        n=len(s)
        cnt = len(t)
        d=defaultdict(int)
        d=Counter(t)
        start=-1
        mini = sys.maxsize
        while r<n:
            if d[s[r]]>0:
                cnt-=1
            d[s[r]]-=1
            while cnt==0:
                if r-l+1<mini:
                    mini=r-l+1
                    start = l
                d[s[l]]+=1
                #this will only be updated when it is present in t, lets take example of aacbab and we have ab as our target to check then you will understand it easily.
                if d[s[l]]>0:
                    cnt+=1
                l+=1
            r+=1
        if start==-1:
            return ""
        return s[start:start+mini]
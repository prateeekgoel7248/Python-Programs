class Solution:
    def minFallingPathSum(self, matrix: List[List[int]]) -> int:
        import sys
        def f(i,j):
            if j<0 or j>=len(matrix[0]):
                return sys.maxsize
            if i==0:
                return matrix[i][j]
            
            if dp[i][j]!=-1:
                return dp[i][j]
            s=matrix[i][j]+f(i-1,j)
            ld=matrix[i][j]+f(i-1,j-1)
            rd=matrix[i][j]+f(i-1,j+1)
            dp[i][j]=min(s,ld,rd)
            return dp[i][j]
        dp=[[-1 for _ in range(len(matrix[0]))]for i in range(len(matrix))]
        return min(f(len(matrix)-1,k) for k in range(len(matrix[0])))
        
class Solution:
    def numIslands(self, grid: List[List[str]]) -> int:
        n=len(grid)
        m=len(grid[0])
        visited=[[0 for _ in range(m)] for i in range(n)]
        def bfs(row,col):
            visited[row][col]=1
            q=[[row,col]]
            while q:
                r,c=q.pop(0)
                rng=[[0,-1],[1,0],[0,1],[-1,0]]
                for i,j in rng:
                        if i+r>=0 and i+r<n and j+c>=0 and j+c<m and (not visited[r+i][c+j]) and grid[r+i][c+j]=='1':
                            q.append([r+i,j+c])
                            visited[r+i][c+j]=1
                            
        cnt=0
        for i in range(n):
            for j in range(m):
                if (not visited[i][j]) and grid[i][j]=='1':
                    # print(visited)
                    cnt+=1
                    bfs(i,j)
        return cnt
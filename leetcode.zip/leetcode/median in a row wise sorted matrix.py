from bisect import bisect_right
def getMedian(matrix):
    # Write your code here.
        r=len(matrix)
        c=len(matrix[0])
        low=1
        high=100000
        #our answer always lies between 1 to 10**4 so it is our search space
        #so we can apply binary search

        #like for a median we want that number who is (n*m)//2 position in sorted 1-d array so for that we can take a mid number and count (as we know that this is a row wise sorted matrix so) how many number in that row is smaller than or equal to that mid and we can us bisect_right for getting the count(becuase it is 0 based) so we will that how many count for that mid in that row
        #and we traverse in the full matrix for that mid 
        #and if the count if less than (n*m//2) then we know that the number should be greater otherwise smalller, 
        
        
        while low<=high:
            mid=low+(high-low)//2
            cnt=0
            for i in range(r):
                cnt+=bisect_right(matrix[i],mid)
            if cnt<=((r*c)//2):
                low=mid+1
            else:
                high=mid-1
        return low

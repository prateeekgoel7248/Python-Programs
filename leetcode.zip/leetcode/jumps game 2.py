class Solution(object):
    def jump(self, nums):
        farthest=0
        jumps=0
        current=0
        for i in range(len(nums)-1):
            farthest=max(farthest,i+nums[i])
            if i==current:
                current = farthest
                jumps+=1
        return jumps
            
        """
        :type nums: List[int]
        :rtype: int
        """
        
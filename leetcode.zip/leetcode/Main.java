import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        System.out.println("Prateek goel");
        Scanner sc= new Scanner(System.in);
        String nm = sc.nextLine();
        int age = sc.nextInt();
        System.out.println(nm+age);
    }
}
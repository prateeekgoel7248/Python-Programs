class Solution:
    def findRedundantConnection(self, edges: List[List[int]]) -> List[int]:
        
        par = [i for i in range(len(edges) + 1)]
        def find(x: int) -> int:
            if x != par[x]: par[x] = find(par[x])
            return par[x]
        def union(x: int, y: int) -> None:
            par[find(y)] = find(x)
        for a,b in edges:
            if find(a) == find(b): return [a,b]
            else: union(a,b)
        # adj = defaultdict(list)
        # for i,j in edges:
        #     adj[i].append(j)
        #     adj[j].append(i)
        # vis=[0 for _ in range(len(edges)+1)]
        # def solve(src):
        #     vis[src]=1
        #     q=[]
        #     q.append([src,-1])
        #     while q:
        #         val,par = q.pop(0)
        #         for n in adj[val]:
        #             # print(n,val)
        #             if not vis[n]:
        #                 q.append([n,val])
        #                 vis[n]=1
        #             elif n!=par:
        #                 return [val,n]
        #     return []
        # print(adj)
        # return solve(1)
        
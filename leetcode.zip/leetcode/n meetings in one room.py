#User function Template for python3

class Solution:
    
    #Function to find the maximum number of meetings that can
    #be performed in a meeting room.
    def maximumMeetings(self,n,start,end):
        # code here
        intervals = list(zip(start, end))
        intervals = sorted(intervals, key=lambda x: x[1])
            
        res = 1
        prev = 0
        for curr in range(1, n):
            if intervals[curr][0] > intervals[prev][1]:
                res += 1
                prev = curr
                    
        return res
#{ 
#  Driver Code Starts
#Initial Template for Python 3
import atexit
import io
import sys

#Contributed by : Prateek Goel

if __name__ == '__main__':
    test_cases = int(input())
    for cases in range(test_cases) :
        n = int(input())
        start = list(map(int,input().strip().split()))
        end = list(map(int,input().strip().split()))
        ob=Solution()
        print(ob.maximumMeetings(n,start,end))
# } Driver Code Ends
t=int(input())
def solve():
    n=int(input())
    lis=list(input().split())
    lis=list(map(int,lis))
    # strin = 
    stri=input()
    strin=[]
    for i in stri:
        strin.append(i)
    # d=dict(zip(lis, strin))
    sorted_lis = sorted(lis)
    if sorted_lis==lis:
        print(0)
        return
    
    # count=0
    n_c=0
    for i in strin:
        if i=="N":
            n_c=n_c + 1
    if n_c==n or  n_c==0:
        print(-1)
        return
        #   count+=1
    import sys
    start=sys.maxsize
    last=-(sys.maxsize)
    
    c=0
    for i in range(n):
        if sorted_lis[i]!=lis[i]:
            start=min(i,start)
            last=max(i,last)
    f1=False
    f2=False
    for i in range(start):
        if strin[i]!=strin[last]:
            f1=True
    for i in range(last,n):
        if strin[i]!=strin[start]:
            f2=True
    if strin[start]!=strin[last] or f1 or f2:
        print(1)
        # return
    else:
        print(2)
        # return 
    
while t:
    t-=1
    solve()
    
    
    
            
    
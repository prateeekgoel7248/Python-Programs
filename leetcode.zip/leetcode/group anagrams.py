class Solution(object):
    def groupAnagrams(self, strs):
        d=dict()
        for i in strs:
            k=sorted(i)
            k=''.join(k)
            # print(k)
            if k not in d:
                d[k] = [i]
            else:
                d[k].append(i)
        return list(d.values())
        
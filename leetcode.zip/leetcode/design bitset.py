class Bitset:

    def __init__(self, size):
        self.flipped = False
        self.size = size
        self.sum = 0
        self.arr = [0] * size
        
    def fix(self, idx):
        if not self.flipped:
            if self.arr[idx] == 1:
                return
            self.arr[idx] = 1
            self.sum += 1
        else:
            if self.arr[idx] == 0:
                return
            self.arr[idx] = 0
            self.sum -= 1
            
    def unfix(self, idx):
        if not self.flipped:
            if self.arr[idx] == 0:
                return
            self.arr[idx] = 0
            self.sum -= 1
        else:
            if self.arr[idx] == 1:
                return
            self.arr[idx] = 1
            self.sum += 1
            
    
    def flip(self):
        self.flipped = not self.flipped 
        
    def all(self):
        if not self.flipped:
            return self.sum == self.size
        else:
            return self.size - self.sum == self.size
        
    def one(self):
        if not self.flipped:
            return self.sum > 0
        else:
            return self.size - self.sum > 0
        
    def count(self):
        if not self.flipped:
            return self.sum
        else:
            return self.size - self.sum

    def toString(self):
        if not self.flipped:
            return "".join(["1" if x == 1 else "0" for x in self.arr])
        else:
            return "".join(["0" if x == 1 else "1" for x in self.arr])
           
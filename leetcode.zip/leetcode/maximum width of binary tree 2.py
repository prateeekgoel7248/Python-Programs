# Definition for a binary tree node.
# class TreeNode(object):
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution(object):
    def widthOfBinaryTree(self, root):
        if not root:
            return 0
        ans=0
        q = []
        q.append([root,0])
        first=0
        last=0
        while q:
            size = len(q)
            mn  = q[0][1]
            for i in range(size):
                cur_id = q[0][1]-mn
                node = q.pop(0)[0]
                if i==0:
                    first = cur_id
                if i==size-1:
                    last = cur_id
                if node.left:
                    q.append([node.left,2*cur_id+1])
                if node.right:
                    q.append([node.right,2*cur_id+2])
            ans= max(ans,last-first+1)
        return ans
        
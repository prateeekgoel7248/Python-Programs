from sys import stdin

def maxMoneyLooted(houses, n) :
    #Your code goes here
#     dp=[0]*(n)
#     dp[0]=houses[0]
    prev=houses[0]
    sprev =0
    for i in range(1,n):
        pick=houses[i]
        if i>1:
            pick = houses[i]+sprev
        npick = prev
        sprev = prev
        prev=max(pick,npick)
    return prev
        





























#taking input using fast I/O method

def takeInput() :
    n = int(stdin.readline().rstrip())
    if n == 0 :
        return list(), 0

    arr = list(map(int, stdin.readline().rstrip().split(" ")))
    return arr, n


#main
arr, n = takeInput()
print(maxMoneyLooted(arr, n))
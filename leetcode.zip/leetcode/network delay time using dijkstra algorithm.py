class Solution(object):
    def networkDelayTime(self, times, N, K):
        graph = collections.defaultdict(list)
        for (u, v, w) in times:
            graph[u].append((v, w))
            
        priority_queue = [(0, K)]
        shortest_path = {}
        while priority_queue:
            w, v = heapq.heappop(priority_queue)
            if v not in shortest_path:
                shortest_path[v] = w
                for v_i, w_i in graph[v]:
                    heapq.heappush(priority_queue, (w + w_i, v_i))
                    
        if len(shortest_path) == N:
            return max(shortest_path.values())
        else:
            return -1
                    
        
        
        
        
        
        
        """
        :type times: List[List[int]]
        :type n: int
        :type k: int
        :rtype: int
        """
        # source to target
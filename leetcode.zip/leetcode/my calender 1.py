class Node:
    def __init__(self,start,end):
        self.start = start
        self.end = end
        self.left=None
        self.right=None

class MyCalendar(object):

    def __init__(self):
        self.root = None

    def insert(self,start,end,root):
        if not root:
            return Node(start,end),True
        if root.start <= start < root.end or root.start< end <=root.end or (root.start>start and root.end< end):
            return root,False
        if start<root.start:
            root.left, success = self.insert(start,end,root.left)
            return root,success
        else:
            root.right, success = self.insert(start,end,root.right)
            return root,success
        # return True
    def book(self, start, end):
        self.root,success = self.insert(start,end,self.root)
        # print(self.root)
        return success
        
        """
        :type start: int
        :type end: int
        :rtype: bool
        """
        


# Your MyCalendar object will be instantiated and called as such:
# obj = MyCalendar()
# param_1 = obj.book(start,end)
class Solution(object):
    def getMoneyAmount(self, n):
        dp=[]
        for i in range(n+2):
            res=[]
            for j in range(n+2):
                res.append(0)
            dp.append(res)
        for i in range(2,n+1):
            for j in range(1,n-i+2):
                end=j+i-1
                import sys
                curMin = sys.maxsize
                for k in range(j,end+1):
                    curMin=min(curMin,k+max(dp[j][k-1],dp[k+1][end]))
                    
                dp[j][end]=curMin
        print(dp)
        return dp[1][n]
        """
        :type n: int
        :rtype: int
        """
        
class Solution:
    def isBipartite(self, graph: List[List[int]]) -> bool:
        def dfs(node,adj,color):
            if color[node]==-1:
                color[node]=1
            for it in adj[node]:
                if color[it]==-1:
                    color[it]=1-color[node]
                    if not dfs(it,adj,color):
                        return False
                elif color[it]==color[node]:
                    return False
            return True
            
        def checkBipartite(adj):
            n=len(adj)
            color=[-1 for _ in range(n)]
            for i in range(n):
                if color[i]==-1:
                    if not dfs(i,adj,color):
                        return False
            return True
        if checkBipartite(graph):
            return True
        else:
            return False
        
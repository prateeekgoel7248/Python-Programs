from math import factorial


def isPalindrome(s):
    i = 0
    j = len(s) - 1
    while i < j:
        if s[i] != s[j]:
            return False
        i += 1
        j -= 1
    return True


def IntList():
    lis = input().split()
    lis = list(map(int, lis))
    # print(lis)
    return lis


def StrList():
    s = input()
    lis = [val for val in s]
    # print(lis)
    return lis


def FloatList():
    lis = input().split()
    lis = list(map(float, lis))
    return lis


def solveByPRateek():
    n = int(input())
    s = input()
    number = [str(i) for i in range(10)]
    lower = [chr(ord('a') + i) for i in range(26)]
    upper = [chr(ord('A') + i) for i in range(26)]
    special = ['#', '@', '*', '&']
    # print(lower)
    n, l, u, sp = 0, 0, 0, 0
    for i in s:
        if i in number:
            n += 1
        elif i in lower:
            l += 1
        elif i in upper:
            u += 1
        elif i in special:
            sp += 1
    if n<1:
        s+='1'
    if l<1:
        s+='a'
    if u<1:
        s+='A'
    if sp<1:
        s+='#'
    if len(s)<7:
        count=7-len(s)
        temp="1" * count
        s+=temp
    print(s)
    return

t = int(input())
for i in range(t):
    print(f"Case {i + 1}: ", end="")
    solveByPRateek()

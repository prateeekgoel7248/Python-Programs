class Solution(object):
    def minOperations(self, grid, x):
        """
        :type grid: List[List[int]]
        :type x: int
        :rtype: int
        """
        
        n_list = []
        
        for r in range(0, len(grid)):
            for c in range(0, len(grid[0])):
                n_list.append(grid[r][c])
                
        
        reminder = n_list[0] % x
        for n in n_list:
            c_reminder = n % x
            
            if(c_reminder != reminder):
                return -1
        
        n_list.sort()
        
        cnt = 0
        if(len(n_list) % 2 == 1):
            
            mid = n_list[len(n_list)//2]
            
            for n in n_list:
                cnt+= abs(n - mid) / x
        else:
            
            mid1 = n_list[len(n_list)//2]
            mid2 = n_list[len(n_list)//2 -1]
            
            cnt1, cnt2 = 0, 0
            
            for n in n_list:
                cnt1 += abs(n-mid1)/x
                cnt2 += abs(n-mid2)/x
                
            cnt = min(cnt1, cnt2)
        
        return int(cnt)
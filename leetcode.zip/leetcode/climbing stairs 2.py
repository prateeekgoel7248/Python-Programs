class Solution(object):
    def climbStairs(self, n):
        # dp=[]
        # dp.append(0)
        # dp.append(1)
        # dp.append(2)
        # for i in range(3,n+1):
        #     dp.append(dp[i-1]+dp[i-2])
        # return dp[n]
        a = b = 1
        for _ in range(n):
            a, b = b, a + b
        return a
        """
        :type n: int
        :rtype: int
        """
        
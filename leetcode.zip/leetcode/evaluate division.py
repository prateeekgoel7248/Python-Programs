class Solution:
    def calcEquation(self, equations: List[List[str]], values: List[float], queries: List[List[str]]) -> List[float]:
        graph = defaultdict(dict)

        for (x, y), value in zip(equations, values):
            graph[x][y] = value
            graph[y][x] = 1 / value  # x / y = value => y / x = 1 / value
        print(graph)

        def query(u: str, v: str, val: float, visited: set) -> float:
            visited.add(u)

            if u == v:
                return val

            for neighbor in graph[u]:
                if neighbor not in visited:
                    # u.parent / u = val and u / neighbor = graph[u][neighbor] so
                    # u.parent / neighbor = val * graph[u][neighbor]
                    out = query(
                        neighbor, v,
                        val * graph[u][neighbor],
                        visited
                    )

                    if out > 0:  # out != -1
                        return out

            return -1

        output = []

        for a, b in queries:
            if a not in graph or b not in graph:
                # one of the variables is not in the graph
                output.append(-1)
            else:
                output.append(query(a, b, 1, set()))

        return output
#         from collections import defaultdict
#         def dfs(source,destination,d,visited,ans,temp):
#             # print("1")
#             # print(visited)
#             if source in visited:
#                 return 
#             if source == destination:
#                 ans=temp
#                 return 
#             visited[source].append(1)
#             # print(visited)
#             for x in d[source]:
#                 dfs(x[0],destination,d,visited,ans,temp*x[1])
#             return 
                
            
#         d=defaultdict(list)
#         for i in range(len(equations)):
#             d[equations[i][0]].append((equations[i][1],values[i]))
#             d[equations[i][1]].append((equations[i][0],1/values[i]))
#         res=[]
#         for i in range(len(queries)):
#             source = queries[i][0]
#             destination = queries[i][1]
            
#             visited = defaultdict(list)
            
#             ans=-1.0
#             temp=1.0
#             if source in d:
#                 # print(source in d)
#                 dfs(source,destination,d,visited,ans,temp)
#             res.append(ans)
#         print(d)
#         print(visited)
#         return res
        
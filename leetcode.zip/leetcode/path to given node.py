# Definition for a  binary tree node
# class TreeNode:
#     def __init__(self, x):
#         self.val = x
#         self.left = None
#         self.right = None

class Solution:
    # @param A : root node of tree
    # @param B : integer
    # @return a list of integers
    
    def get(self,root,val,ans):
        if not root:
            return False
        ans.append(root.val)
        if root.val == val:
            return True
        if self.get(root.left,val,ans) or self.get(root.right,val,ans):
            return True
        ans.pop()
        return False
            
        
            
    
    def solve(self, root, B):
        ans=[]
        if not root:
            return ans
        self.get(root,B,ans)
        return ans

# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution:
    def mergeNodes(self, head: Optional[ListNode]) -> Optional[ListNode]:
        # temp=head
        zero=head
        p = head.next
        while p:
            if p.val!=0:
                zero.val+=p.val
            else:
                if not p.next:
                    zero.next=None
                else:
                    zero.next = p
                zero=p
            p=p.next
        return head
            
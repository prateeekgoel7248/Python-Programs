class Solution(object):
    def countPrimes(self, n):
        if n==0 or n==1 or n==2: return 0
        PrimeTable=[True]*(n)
        p=2
        # Since p>=sqrt(n)
        while p**2<n:
            if PrimeTable[p]==True:
                for i in range(p**2,n,p): PrimeTable[i]=False
            p += 1
        # Exclude 0,1 True values initially set 
        return sum(PrimeTable[2:])
                
        """
        :type n: int
        :rtype: int
        """
        
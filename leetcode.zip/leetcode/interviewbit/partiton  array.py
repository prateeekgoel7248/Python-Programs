class Solution:
    # @param A : integer
    # @param B : list of integers
    # @return an integer
    def solve(self, A, B):
        suffix=[0]*A
        s=sum(B)
        if s%3!=0:
            return 0
        p=s//3
        local_sum=0
        for i in range(A-1,-1,-1):
            local_sum+=B[i]
            if local_sum==p:
                suffix[i]=1
        for i in range(A-2,-1,-1):
            suffix[i]+=suffix[i+1]
        local_sum=0
        ans=0
        for i in range(A-2):
            local_sum+=B[i]
            if local_sum==p:
                ans+=suffix[i+2]
        return ans

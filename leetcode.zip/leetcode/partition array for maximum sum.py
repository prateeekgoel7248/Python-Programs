class Solution:
    def maxSumAfterPartitioning(self, arr: List[int], k: int) -> int:
        # @lru_cache
        def solve(ind,dp):
            if ind==len(arr):
                return 0
            if dp[ind]!=-1:
                return dp[ind]
            mx_ans =-sys.maxsize
            mx=-sys.maxsize
            l=0
            for j in range(ind,min(len(arr),ind+k)):
                l+=1
                mx=max(mx,arr[j])
                mx_ans = max(mx_ans,(l*mx)+solve(j+1,dp))
            dp[ind]=mx_ans
            return mx_ans
        dp=[0 for _ in range(len(arr)+1)]
        # return solve(0,dp)
        for ind in range(len(arr)-1,-1,-1):
            mx_ans =-sys.maxsize
            mx=-sys.maxsize
            l=0
            for j in range(ind,min(len(arr),ind+k)):
                l+=1
                mx=max(mx,arr[j])
                mx_ans = max(mx_ans,(l*mx)+dp[j+1])
            dp[ind]=mx_ans
        return dp[0]
class Solution(object):
    def nearestValidPoint(self, x, y, points):
        index, smallest = -1, pow(10,10)
        for i, (r, c) in enumerate(points):
            dx, dy = x - r, y - c
            if dx * dy == 0 and abs(dx + dy) < smallest:
                smallest = abs(dx + dy)
                index = i
        return index
        # res=[]
        # for i in points:
        #     if i[0]==x or i[1]==y:
        #         res.append(i)
        # if len(res)==0:
        #     return -1
        # res=sorted(res)
        # print(res)
        # return abs(res[0][0]-x)+abs(res[0][1]-y)
        """
        :type x: int
        :type y: int
        :type points: List[List[int]]
        :rtype: int
        """
        
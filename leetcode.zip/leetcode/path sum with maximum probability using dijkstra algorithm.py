class Solution(object):
    def maxProbability(self, n, edges, succProb, start, end):
			#This is a variation of std djikstra's 
			#dijkstra's use: find the shortest path from a source to all other nodes.
			#here,the distance is measured by prob.

			#create a Adjacency-list from the edges
			graph = [[] for _ in range(n)]
			for i,(u,v) in enumerate(edges):
				graph[u].append([v,succProb[i]])
				graph[v].append([u,succProb[i]])

			#so,use a priorityQueue,for relaxation of edges
			pq = [[-1,start]]

			#distance vector from start to all other nodes
			dist = collections.defaultdict(int)
			dist[start] = -1

			while pq:
				d,node = heapq.heappop(pq)            
				for nei,w in graph[node]:
					d2 = d*w
					if d2 < dist[nei]:
						heapq.heappush(pq,[d2,nei])
						dist[nei] = d2

			return -dist[end]
        
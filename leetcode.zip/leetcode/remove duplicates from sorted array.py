class Solution:
    # @param A : list of integers
    # @return an integer
    def removeDuplicates(self, A):
        n=len(A)
        i=0
        for j in range(1,n):
            if A[i]!=A[j]:
                i+=1
                A[i]=A[j]

        return i+1

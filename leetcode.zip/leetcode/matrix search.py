class Solution:
    # @param A : list of list of integers
    # @param B : integer
    # @return an integer
    def searchMatrix(self, A, B):
        i=0
        j=len(A[0])-1
        while i>=0 and i<len(A) and j>=0 and j<len(A[0]):
            if A[i][j]==B:
                return 1
            elif A[i][j]>B:
                j-=1
            else:
                i+=1
        return 0
class Solution:
    def minSubArrayLen(self, target: int, nums: List[int]) -> int:
        mn=sys.maxsize
        i=0
        j=0
        s=0
        while j<len(nums):
            s+=nums[j]
            if s>=target:
                while i<len(nums) and s>=target:
                    mn=min(mn,j-i+1)
                    s-=nums[i]
                    i+=1
                    
                    
            j+=1
        return mn if mn!=sys.maxsize else 0
            










class Solution(object):
    def minSubArrayLen(self, target, nums):
        def solve(mid):
            cnt=0
            s=0
            for i in range(mid):
                s+=nums[i]
            i=0
            j=mid
            mx=s
            while j!=len(nums):
                s-=nums[i]
                i+=1
                s+=nums[j]
                mx=max(mx,s)
                j+=1
            # print(mid,mx)
            return mx
                   
        low=1
        high=len(nums)+1
        flag=False
        while low<high:
            mid=(low+high)//2
            if solve(mid)>=target:
                high=mid
                flag=True
            else:
                low=mid+1
        if flag:
            return low
        return 0
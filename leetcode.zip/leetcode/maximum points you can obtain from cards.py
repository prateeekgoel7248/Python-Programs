class Solution(object):
    def maxScore(self, cardPoints, k):
        l=len(cardPoints)-k
        su=sum(cardPoints)
        if l==0:
            return su
        i=0
        j=l
        mn=sys.maxsize
        s=sum(cardPoints[:j])
        mn=min(mn,s)
        while j<len(cardPoints):
            temp=cardPoints[i]
            i+=1
            s-=temp
            s+=cardPoints[j]
            mn=min(mn,s)
            j+=1
        return su-mn
            
                
            
            
            
        """
        :type cardPoints: List[int]
        :type k: int
        :rtype: int
        """
        
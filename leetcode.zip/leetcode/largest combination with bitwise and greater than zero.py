class Solution(object):
    def largestCombination(self, candidates):
        bins = [bin(c)[2:] for c in candidates]
        maxLen = max(len(b) for b in bins)
        ans = 0
        for i in range(1, maxLen + 1):
            temp = 0
            for b in bins:
                if len(b) < i:
                    #here we are checking that the length of the binray is lesser than the ith position if yes then we dont have to do anything for it so we for next iteration
                    
                    continue
                elif b[-i] == '1':
                    #here we are checking that the i-th bit is 1 for all of the binary representation of the number 
                    #if yes we are doing temp+=1
                    temp += 1
            #temp can be max of length of the candidates
            ans = max(ans, temp)
        return ans
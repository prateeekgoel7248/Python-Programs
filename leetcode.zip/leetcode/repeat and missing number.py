class Solution:
    # @param A : tuple of integers
    # @return a list of integers
    def repeatedNumber(self, A):
        lis=[0 for _ in range(len(A)+1)]
        for i in A:
            lis[i]+=1
        a,b=0,0
        for i in range(1,len(A)+1):
            if lis[i]==0:
                b=i
            elif lis[i]==2:
                a=i
        return (a,b)

                


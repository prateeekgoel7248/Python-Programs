from typing import List
import sys
def cost(n: int, c: int, cuts: List[int]) -> int:
    # Write your code here.
    def solve(i,j,dp):
        if i>j:
            return 0
        if dp[i][j]!=-1:
            return dp[i][j]
        mn= sys.maxsize
        for k in range(i,j+1):
            cut = cuts[j+1]-cuts[i-1]+solve(i,k-1,dp)+solve(k+1,j,dp)
            mn = min(mn,cut)
        dp[i][j]=mn
        return mn
    
    dp=[[0 for _ in range(c+2)] for i in range(c+2)]
    cuts.insert(0,0)
    cuts.append(n)
    cuts.sort()
#     return solve(1,l,dp)
    for i in range(c,0,-1):
        for j in range(1,c+1):
            if i>j: continue
            mn= sys.maxsize
            for k in range(i,j+1):
                cut = cuts[j+1]-cuts[i-1]+dp[i][k-1]+dp[k+1][j]
                mn = min(mn,cut)
            dp[i][j]=mn
    return dp[1][c]
    
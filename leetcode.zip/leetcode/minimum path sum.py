class Solution(object):
    import sys
    def f(self,i,j,s,grid,dp):
        if i==0 and j==0:
            return grid[i][j]
        
        if i< 0 or j<0:
            return sys.maxint
        if dp[i][j]!=-1:
            return dp[i][j]
        s+=grid[i][j]+min(self.f(i-1,j,s,grid,dp),self.f(i,j-1,s,grid,dp))
        dp[i][j]=s
        return s
        
    def minPathSum(self, grid):
        dp=[[0 for _ in range(len(grid[0]))]for i in range(len(grid))]
        for i in range(len(grid)):
            for j in range(len(grid[0])):
                if i==0 and j==0:
                    dp[i][j]=grid[i][j]
                else:
                    up=grid[i][j]
                    down=grid[i][j]
                    up+=dp[i-1][j] if i>0 else sys.maxint
                    down+=dp[i][j-1] if j>0 else sys.maxint
                    dp[i][j]=min(up,down)
        return dp[len(grid)-1][len(grid[0])-1]
        # print(dp)
        # return self.f(len(grid)-1,len(grid[0])-1,0,grid,dp)
        
        """
        :type grid: List[List[int]]
        :rtype: int
        """
        
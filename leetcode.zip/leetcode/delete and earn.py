class Solution(object):
    def deleteAndEarn(self, nums):
        A = [0] * (max(nums or [0]) + 1)
        for i in nums:
            A[i] += i
        print(A)
        pre, cur = 0, 0
        for i in A:
            pre, cur = cur, max(cur, pre + i)
        return cur
        
class Solution(object):
    def calculateTax(self, brackets, income):
        c=0
        if brackets[0][0]>=income:
            return (brackets[0][1]*income*1.0)/100
        else:
            c+=(brackets[0][0]*brackets[0][1]*1.0)/100
            income-=brackets[0][0]
        i = 1 
        while i<len(brackets) and income>0:
            x  = brackets[i][0]-brackets[i-1][0]
            if x>=income:
                c+=(brackets[i][1]*income*1.0)/100
                income=0
            else:
                c+=(brackets[i][1]*x*1.0)/100
                income-=x 
            i+=1 
        return c
        
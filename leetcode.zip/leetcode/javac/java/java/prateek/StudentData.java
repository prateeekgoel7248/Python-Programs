import java.util.ArrayList;
class StudentData{
	public static void main(String [] args){
		// Student [] st= new Student[3];
		Student st0 = new Student();
		Student st1 = new Student();
		st0.setRoll(1);
		st0.setName("Prachi");
		st1.setRoll(2);
		st1.setName("Prateek");
		// Scanner sc = new Scanner(System.in);
		// for(int i=0;i<3;i++){
		// 	System.out.println("Enter the rollNo of "+i+1);
		// 	st[i].setRoll()
		// }
		// ArrayList<ArrayList<Integer,String>> record = new ArrayList<ArrayList<Integer,String>>();
		ArrayList<Student> record = new ArrayList<Student>();
		record.add(st0);
		record.add(st1);
		System.out.println(record);
		for(Student st:record){
			System.out.println(st);
		}
	}
	// 	ArrayList<Integer,String> temp = new ArrayList<Integer,String>();
	// 	for(int i=0;i<2;i++){
			
	// 		temp.add(st[i].getRoll(),st[i].getName());
	// 		// record.add(temp);
			
	// 	}
	// 	System.out.println(temp);
	// }
}
#User function Template for python3

class Solution:

    def findcount(self,s,l,r):
        total = 0
        while l >= 0 and r < len(s) and s[l] == s[r]:
            total += 1
            l -= 1
            r += 1 
            
        return total
        
    def CountPS(self, S, N):
        # code here
        count = 0
        for i in range(len(S)):
            count += self.findcount(S,i,i) + self.findcount(S,i,i+1)                        
        return count - N


#{ 
 # Driver Code Starts
#Initial Template for Python 3

if __name__ == '__main__':

    t = int(input())

    for _ in range(t):
        N = int(input())
        S = input()

        solObj = Solution()

        print(solObj.CountPS(S,N))
# } Driver Code Ends
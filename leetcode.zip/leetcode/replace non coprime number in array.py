class Solution(object):
    def replaceNonCoprimes(self, nums):
        def gcd(a,b):
            if b==0:
                return a
            return gcd(b,a%b)
        stack=[nums[0]]
        for i in nums[1:]:
            y=i
            while len(stack)>0 and gcd(y,stack[-1])>1:
                x=stack.pop()
                y=(x*y)//gcd(x,y)
            stack.append(y)
            # print(stack)
        return stack
                
        """
        :type nums: List[int]
        :rtype: List[int]
        """
        
class Solution:
    def minOperations(self, nums: List[int], x: int) -> int:
        n=len(nums)
        s=0
        from collections import defaultdict
        d=defaultdict(int)
        for i in range(n):
            s+=nums[i]
            d[s]=i
        #why we are assigning the sum(prefix sum) to the index in the hashmap
        #because it will helpful to know that this value exist or not.
        
        if x>s:
            return -1
        d[0]=0
        longest=0
        s-=x
        val=0
        #this val -s condition will work when the diffrence is positive so means the sum of that time of index is greater than what we required.
        #here if we got the val 25 in the example shown then we will sure that there may be exist the longest subarray of val 20. 
        for i in range(n):
            val+=nums[i]
            # print(val-s)
            if val-s in d:
                #why are you not doing +1 in the else part
                #because we are defining the d[0] as 0 and we take the index from 0 then we have to do +1 to get the length like from 0 index to 2 index then 2-0+1 bt if the value exist in the middle and we have provided the correct index(0 based) so we dont have to add +1 like we got 1 and 4 index so length from 1st index to 4th index will be 4-1 which is 3
                if val-s==0:
                    longest = max(longest,i-d[val-s]+1)
                else:
                    longest = max(longest,i-d[val-s])
        if s==0:
            return n
        return -1 if longest==0 else n-longest
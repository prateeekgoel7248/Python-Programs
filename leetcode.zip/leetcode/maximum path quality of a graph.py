#it is an simple recursion based question and it is not a hard question, it is easy if you remember the concept of recursion.

class Solution:
    def maximalPathQuality(self, values: List[int], edges: List[List[int]], maxTime: int) -> int:
        n=len(values)
        adj=defaultdict(list)
        for i,j,tm in edges:
            adj[i].append([j,tm])
            adj[j].append([i,tm])
        vis=[0 for _ in range(n)]
        
        def solve(node,val,mxT):
            if mxT<0:
                return 
            vis[node]+=1
            if vis[node]==1:
                val+=values[node]
            if node==0:
                mx[0]=max(mx[0],val)
            for neigh in adj[node]:
                u,t = neigh[0],neigh[1]
                solve(u,val,mxT-t)
            vis[node]-=1
        mx=[0]
        solve(0,0,maxTime)
        return mx[0]

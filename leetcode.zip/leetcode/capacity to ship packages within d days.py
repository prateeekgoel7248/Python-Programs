#just an easy question 
#take a intuition from the previous solvedd question allocate minimum number of pages.
class Solution:
    def shipWithinDays(self, w: List[int], days: int) -> int:
        def valid(cap):
            s=1
            temp=cap
            for i in w:
                temp-=i
                if temp<0:
                    temp=cap
                    temp-=i
                    s+=1
            return s<=days
                    
                    
                
        start=max(w)
        end=sum(w)
        res=-1
        while start<=end:
            mid = start+(end-start)//2
            if valid(mid):
                end=mid-1
                res=mid
            else:
                start=mid+1
        return res
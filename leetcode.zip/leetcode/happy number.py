class Solution(object):
    def isHappy(self, n):
        if n==1:
            return True
        s=0
        
        # d=n%10
        while s!=1 and s!=4:
            s=0
            for i in str(n):
                s=s+(int(i)*int(i))
            n=s
        if s==1:
            return True
        else:
            return False
            
#         n, s = str(n), 0
#         while s != 1 and s != 4:
#             s = 0
#             for i in n:
#                 s += int(i) ** 2
#             n = str(s)
#         if s ==  1:
#             return True
#         else:
#             return False
            

        
        """
        :type n: int
        :rtype: bool
        """
        
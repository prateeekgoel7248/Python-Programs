# Definition for a binary tree node.
# class TreeNode(object):
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
from collections import deque
class Solution(object):
   def minDepth(self, root):
        if root is None:
            return 0

        # Method-1: DFS
        # return get_depth(root)

        # Method-2: BFS
        q, output = deque([root]), 0
        # print(q)

        while q:
            output += 1
            print(len(q))
            for _ in range(len(q)):
                node = q.popleft()
                # if output==1:
                #     print(node)
                if node.left is None and node.right is None:
                    return output

                if node.left is not None:
                    q.append(node.left)

                if node.right is not None:
                    q.append(node.right)

        return output
        """
        :type root: TreeNode
        :rtype: int
        """
        
# Definition for a binary tree node.
# class TreeNode(object):
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution(object):
    def traversal(self, root, inorder):
        if root:
            self.traversal(root.left, inorder)
            
            self.traversal(root.right, inorder)
            inorder.append(root.val)
    # def inorderTraversal(self, root):
        
    def postorderTraversal(self, root):
        inorder = []
        self.traversal(root, inorder)
        return inorder
        """
        :type root: TreeNode
        :rtype: List[int]
        """
        
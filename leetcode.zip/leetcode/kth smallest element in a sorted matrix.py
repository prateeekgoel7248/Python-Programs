class Solution(object):
    def cntEleLessThanEqualTo(self,matrix,mid):
        j=len(matrix)-1
        cnt=0
        for i in range(len(matrix)):
            while j>=0 and matrix[i][j]>mid:
                j-=1
            cnt+=(j+1)
        return cnt
    def kthSmallest(self, matrix, k):
        n=len(matrix)
        l = matrix[0][0]
        h=matrix[-1][-1]
        while l<=h:
            mid = (l+h)//2
            if self.cntEleLessThanEqualTo(matrix,mid) <k:
                l=mid+1
            else:
                h=mid-1
        return l
        
        
        """
        :type matrix: List[List[int]]
        :type k: int
        :rtype: int
        """
        
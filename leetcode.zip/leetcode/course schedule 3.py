class Solution:
    def scheduleCourse(self, courses: List[List[int]]) -> int:
        courses = sorted(courses,key=lambda x:x[1])
        heap=[]
        #we are maintaing a heap for getting the maximun course duration in less time complecity  
        s=0
        #here it is storing the time we have taken
        for i in courses:
            #if the length of the course is less than or equal to their duration then only we can finish the course
            if i[0]<=i[1]:
                #here we are checking that the course we are taking and the time we have till now is less than or equal to time completion of that course
                #if yes than we will be taking the course and processed further
                #else not then we are swapping the current course with the maximum course we have taken till now
                if i[0]+s <=i[1]:
                    heapq.heappush(heap,-i[0])
                    s+=i[0]
                else:
                    if (-heap[0])>i[0]:
                        s+=heapq.heappop(heap)
                        s+=i[0]
                        heapq.heappush(heap,-i[0])
        return len(heap)
        
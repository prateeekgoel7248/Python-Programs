class Solution:
    def minimizedMaximum(self, n: int, q: List[int]) -> int:
        def solve(val):
            cnt=0
            for i in q:
                cnt+=(i//val)
                if i%val:
                    cnt+=1
            return cnt
        low=1
        high=max(q)+1
        ans=0
        while low<high:
            mid=(low+high)//2
            temp=solve(mid)
            # print(temp,mid)
            if temp<=n:
                ans=mid
                high=mid
            else:
                low=mid+1
        return ans
#simple binary search solution
            
        
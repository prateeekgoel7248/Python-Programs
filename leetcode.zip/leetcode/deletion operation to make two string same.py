class Solution(object):
    def minDistance(self, word1, word2):
        
        def lcs(x,y,m,n):
            t=[[0 for i in range(n+1)] for j in range(m+1)]
                
            # for i in range(m+1):
            #     for j in range(n+1):
            for i in range(1,m+1):
                for j in range(1,n+1):
                    if x[i-1]==y[j-1]:
                        t[i][j]=1+t[i-1][j-1]
                    else:
                        t[i][j]=max(t[i-1][j],t[i][j-1])
            # print(t[m][n])
            return t[m][n]
        # print(len(word1),len(word2))
        return len(word1)+len(word2) -2*(lcs(word1,word2,len(word1),len(word2)))
        # return 2
                    
        
        """
        :type word1: str
        :type word2: str
        :rtype: int
        """
        
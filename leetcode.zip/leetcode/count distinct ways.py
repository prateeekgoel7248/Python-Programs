def countDistinctWays(nStairs: int) -> int:
    #  Write your code here.
    def solve(ind,dp):
        if ind<2:
            return 1
        if dp[ind]!=-1:
            return dp[ind]
        dp[ind]=solve(ind-1,dp)+solve(ind-2,dp)
        return dp[ind]%(10**9+7)
    dp=[-1 for _ in range(nStairs+1)]
    return solve(nStairs,dp)

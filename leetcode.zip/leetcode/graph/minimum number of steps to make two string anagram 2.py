class Solution(object):
    def minSteps(self, s, t):
        from collections import Counter
        d=Counter(s)
        for i in t:
            if i in d:
                d[i]-=1
            else:
                d[i]=-1
        s=0
        for i,j in d.items():
            s+=abs(j)
        return s
        """
        :type s: str
        :type t: str
        :rtype: int
        """
        
class Solution(object):
    def smallestNumber(self, s):
        res, stack = [], []
        for i,c in enumerate(s + 'I', 1):
            stack.append(str(i))
            if c == 'I':
                res += stack[::-1]
                stack = []
        return ''.join(res)


class Solution:
    def smallestNumber(self, pattern: str) -> str:
        dq = [1] # [1,2,3,5,4,6]
        tmp = [] # []
        i = 2
        for p in pattern:
            if p == 'I':
                while tmp:
                    dq.append(tmp.pop())
                dq.append(i)
                i += 1
            else:
                tmp.append(dq.pop())
                dq.append(i)
                i += 1
        while tmp:
            dq.append(tmp.pop())
        return ''.join(map(str,dq))
def minInsertion(s):
    # Write the function here.
    n=len(s)
    t=s[::-1]
    m= len(t)
#     dp=[[0 for _ in range(m+1)] for i in range(n+1)]
    prev=[0]*(m+1)
    curr = [0]*(m+1)
    ans=0
    for i in range(1,n+1):
        for j in range(1,m+1):
            if s[i-1]==t[j-1]:
                curr[j]=1+prev[j-1]
#                 ans=max(ans,curr[j])
            else:
                curr[j]=max(prev[j],curr[j-1])
        prev = curr[:]
    return n-prev[n]

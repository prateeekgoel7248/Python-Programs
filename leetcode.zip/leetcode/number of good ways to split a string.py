class Solution(object):
    def numSplits(self, s):
        
#approach 1

        prefix=Counter()        #Counter for prefix
        suffix=Counter(s)       #Counter for suffix
        count=0
        n=len(s)
        
        for i in range(n-1):
            prefix[s[i]]+=1
            suffix[s[i]]-=1
            
            if suffix[s[i]]==0:
                suffix.pop(s[i])
            
            if len(prefix)==len(suffix):
                count+=1
        
        return count
    
    #approach 2

        if len(s) < 2:
            return 0
        if len(s) == 2:
            return 1
        
        first = {}
        last = {}
        for i, c in enumerate(s):
            if c not in first:
                first[c] = i
            last[c] = i
        
        index = first.values() + last.values()
        index.sort()
        
        mid = len(index)//2
        return index[mid] - index[mid-1]
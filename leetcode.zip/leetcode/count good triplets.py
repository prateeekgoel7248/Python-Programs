class Solution(object):
    def countGoodTriplets(self, arr, a, b, c):
#         L = len(arr)
#         n = 0
        
#         for i in range(L-2):
#             x = arr[i]
#             for j in range(i+1,L-1):
#                 y = arr[j]
#                 print(y)
#                 if abs(x-y) <= a:
#                     print(x,y)
#                     for k in range(j+1,L):
#                         z = arr[k]
#                         print(x,y,z)
#                         if abs(y-z)<=b and abs(x-z)<=c:
#                             print("a")
#                             n += 1
# 		return n
        x, count = len(arr), 0
        for i in range(x-2):
            for j in range(i+1,x-1):
                if abs(arr[i] -arr[j]) <= a:
                    for k in range(j+1,x):
                        if abs(arr[j] -arr[k]) <= b and abs(arr[i] -arr[k]) <= c:
                            count += 1
        return count
        """
        :type arr: List[int]
        :type a: int
        :type b: int
        :type c: int
        :rtype: int
        """
        
def hotelBooking(self,arrive,depart,k):
        arrive.sort()
        depart.sort()
        n=len(arrive)
        j=0
        for i in range(n):
            K-=1
            if K==-1:
                return False
            if i+1 < n :
                if arrive[i+1]<=depart[j]:
                    continue
                elif depart[j]<=arrive[i+1]:
                    K+=1
                    j+=1
        return True
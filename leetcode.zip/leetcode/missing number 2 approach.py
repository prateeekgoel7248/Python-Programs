class Solution(object):
    def missingNumber(self, nums):
    #approach1
        n=len(nums)
        return (n*(n+1))//2 - sum(nums)
    
    #approach 2
        n=len(nums)
        for i in range(len(nums)):
            n^=i
            n^=nums[i]
        return n
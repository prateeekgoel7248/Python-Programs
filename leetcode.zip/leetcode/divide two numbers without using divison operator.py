class Solution:
	# @param A : integer
	# @param B : integer
	# @return an integer
	def divide(self, A, B):
		# return A//B
        import sys
        int_max=sys.maxsize
		if B==0:
			return int_max
		if A==0 or (A<B and A>0):
			return 0
		if B==1:
			return A
		ans=0
		sign=-1 if (A<0and B>0)or (A>0 and B<0) else 1
		A=abs(A)
		B=abs(B)
		while A>=B:
			q=1
			temp=B
			while temp<=A:
				temp<<=1
				q<<=1
			ans+=(q>>1)
			ans=int_max if ans>int_max else ans
			A-=(temp>>1)
		res=  ans*sign
		if res>2147483647:
			return 2147483647
		else:
			return res

        

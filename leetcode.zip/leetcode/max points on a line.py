class Solution(object):
    def maxPoints(self, points):
        def gcd(a,b):
            if b==0:
                return a
            return gcd(b,a%b)
        cnt=0
        n = len(points)
        
        for i in range(n):
            d = defaultdict(int)
            dup=0
            for j in range(i,n):
                dy = points[i][1]-points[j][1]
                dx = points[i][0]-points[j][0]
                if dx==0 and dy==0:
                    dup+=1
                else:
                    g = gcd(dy,dx)
                    dy//=g
                    dx//=g
                    d[(dx,dy)]+=1
            cnt=max(cnt,dup)
            for i,j in d.items():
                cnt=max(cnt,j+dup)
        return cnt
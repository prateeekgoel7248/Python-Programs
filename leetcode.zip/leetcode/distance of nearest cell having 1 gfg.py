import collections
class Solution:

    #Function to find distance of nearest 1 in the grid for each cell.
	def nearest(self, grid):
		n=len(grid)
		m=len(grid[0])
		vis=[[False for _ in range(m)] for i in range(n)]
        dis=[[0 for _ in range(m)] for i in range(n)]
        q=collections.deque()
        for i in range(n):
            for j in range(m):
                if(grid[i][j]):
                    q.append((i,j,0))
                    vis[i][j]=True
        while q:
            row,col,steps = q.popleft()
            dis[row][col]=steps
            x=[-1,0,1,0]
            y=[0,1,0,-1]
            for i in range(4):
                r1 = row - x[i]
                c1 = col - y[i]
                if r1>=0 and r1<n and c1>=0 and c1<m and not vis[r1][c1]:
                    q.append((r1,c1,steps+1))
                    vis[r1][c1]=True
        return dis
                    
            
        
        
        
        
        
#{ 
 # Driver Code Starts
if __name__ == '__main__':
	T=int(input())
	for i in range(T):
		n, m = map(int, input().split())
		grid = []
		for _ in range(n):
			a = list(map(int, input().split()))
			grid.append(a)
		obj = Solution()
		ans = obj.nearest(grid)
		for i in ans:
			for j in i:
				print(j, end = " ")
			print()

# } Driver Code Ends
def permute(nums):
    res = []
    count=[0]
    
    dfs(nums, [], res,count)
    
    if len(res)==0:
        print(-1)

def dfs(nums, path, res,count):
    if not nums and count[0]==0:
        # res.append(path)
        s=0
        for i in range(len(path)-1):
            s+=path[i]*path[i+1]
        if s%2==1 and count[0]==0:
            res.append(path)
            temp=path
            temp=list(map(str,temp))
            print(' '.join(temp))
            count[0]+=1
        return res
        
            
    for i in range(len(nums)):
        if count[0]==0:
            dfs(nums[:i]+nums[i+1:], path+[nums[i]], res,count)


t=int(input())
while t:
    t-=1
    n=int(input())
    lis=input().split()
    lis=list(map(int,lis))
    permute(lis)
    

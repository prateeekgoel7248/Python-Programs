"""
# Definition for a Node.
class Node:
    def __init__(self, x: int, next: 'Node' = None, random: 'Node' = None):
        self.val = int(x)
        self.next = next
        self.random = random
"""

class Solution:
    def copyRandomList(self, head: 'Optional[Node]') -> 'Optional[Node]':
        if not head:
            return head
        cur=head
        #for the next pointers
        # we are giving the nodes between the nodes of original list
        #1->3 to 1->1`->3
        while cur:
            temp=cur.next
            cur.next=Node(cur.val)
            cur.next.next=temp
            cur=temp
        cur=head
        #now we are doing the step 2 for the purpose of random variable
        while cur:
            if cur:
                cur.next.random=cur.random.next if cur.random else None
            cur=cur.next.next
        #now we are making the original list back and making our resultant list also
        orig=head
        copy=head.next
        temp=copy
        while orig:
            orig.next=orig.next.next
            copy.next=copy.next.next if copy.next else copy.next
            orig=orig.next
            copy=copy.next
        return temp
                
        
        
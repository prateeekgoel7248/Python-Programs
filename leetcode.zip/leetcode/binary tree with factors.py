class Solution(object):
    
        
    def numFactoredBinaryTrees(self, arr):
        # def solve(root,dp):
        #     if root in dp:
        #         return dp[root]
        #     cnt=1
        #     for i in arr:
        #         if root%i==0 and (root/i) in count:
        #             cnt+=solve(i,dp)*solve(root//i,dp)
        #     dp[root]=cnt
        #     return cnt
        dp=defaultdict(int)
        count=Counter(arr)
        ans=0
        arr.sort()
        for root in arr:
            cnt=1
            for i in arr:
                if root%i==0 and (root/i) in count:
                    cnt+=dp[i]*dp[root//i]
            dp[root]=cnt
            ans+=cnt
        return ans%(10**9+7)
        
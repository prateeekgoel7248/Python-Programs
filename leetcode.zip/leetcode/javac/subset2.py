class Solution:
    # @param A : list of integers
    # @return a list of list of integers
    def subsetsWithDup(self, nums):
# class Solution:
#     def subsetsWithDup(self, nums: List[int]) -> List[List[int]]:
        res = []
        nums.sort()
        
        def dfs(i, cur):
            # base case
            if i >= len(nums):
                res.append(cur[:])
                return
            
            # dealing with cases which include ith element
            cur.append(nums[i])
            dfs(i+1, cur)
            cur.pop()
            
            # dealing with cases which DONT include ith element
            while i+1 < len(nums) and nums[i] == nums[i+1]:
                i += 1
            dfs(i+1, cur)
        
        dfs(0, [])
        return sorted(res)
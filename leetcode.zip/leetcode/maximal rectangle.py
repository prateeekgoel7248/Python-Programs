class Solution(object):
    def mah(self,heights):
        def nsr(arr):
            ans=[]
            stack=[]
            for i in range(len(arr)-1,-1,-1):
                while stack and stack[-1][1]>=arr[i]:
                    stack.pop()
                if not stack:
                    ans.append(len(arr))
                else:
                    ans.append(stack[-1][0])
                stack.append([i,arr[i]])
            return ans[::-1]
        def nsl(arr):
            ans=[]
            stack=[]
            for i in range(len(arr)):
                while stack and stack[-1][1]>=arr[i]:
                    stack.pop()
                if not stack:
                    ans.append(-1)
                else:
                    ans.append(stack[-1][0])
                stack.append([i,arr[i]])
            return ans
        mx=-1
        nslArr= nsl(heights)
        nsrArr= nsr(heights)
        for i in range(len(heights)):
            mx=max(mx,heights[i]*(nsrArr[i]-nslArr[i]-1))
        return mx
    def maximalRectangle(self, matrix):
        mx=-1
        res = [0 for _ in range(len(matrix[0]))]
        for i in range(len(matrix)):
            for j in range(len(matrix[0])):
                if matrix[i][j]=="0":
                    res[j]=0
                else:
                    res[j] += int(matrix[i][j])
            mx=max(mx,self.mah(res))
                
        return mx
        """
        :type matrix: List[List[str]]
        :rtype: int
        """
        
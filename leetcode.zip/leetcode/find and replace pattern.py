class Solution(object):
    def findAndReplacePattern(self, words, pattern):
        b = pattern

        def is_iso(a):
            return len(a) == len(b) and len(set(a)) == len(set(b)) == len(set(zip(b, a)))

        return filter(is_iso, words)
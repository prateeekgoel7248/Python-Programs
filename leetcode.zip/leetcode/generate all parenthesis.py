class Solution:
    # @param A : string
    # @return an integer
    def isValid(self, A):
        p=[]
        b=[]
        c=[]
        for i in A:
            if len(p)==0:
                p.append(i)
            elif p[-1]=="(" and i==")":
                p.pop()
            
            elif p[-1]=="[" and i=="]":
                p.pop()
            
            elif p[-1]=="{" and i=="}":
                p.pop()
            elif p[-1]=="(" and i=="]":
                return 0
            elif p[-1]=="{" and i=="]":
                return 0
            elif p[-1]=="[" and i==")":
                return 0
            else:
                p.append(i)
        if len(p)==0:
            return 1
        else:
            return 0
            
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.ListIterator;
class Student{
	int rollNo;
	String Name;
	public void setName(String nn){
		this.Name=nn;
	}
	public void setRoll(int rn){
		this.rollNo=rn;
	}
	public int getRoll(){
		return this.rollNo;
	}
	public String getName(){
		return this.Name;
	}
	
}

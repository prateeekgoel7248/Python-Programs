A =  [[1, 4],[2, 3],[4, 6],[8, 9]]
l=sorted(A)
ans=[]
print(l)
ans.append(l[0])
print(ans)
for i in range(1,len(l)):
    if ans[-1][1]>=l[i][0]:
        ans[-1][1]=min(ans[-1][1],l[i][1])
    else:
        ans.append(l[i])
print(len(ans))
# return s
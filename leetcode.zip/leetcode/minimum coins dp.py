from typing import List
import sys
def minimumElements(arr: List[int], p: int) -> int:
    # Write your code here.
    def solve(ind,target,dp):
        if ind==0:
            if target%arr[ind]==0:
                return target//arr[ind]
            else:
                return sys.maxsize
        if dp[ind][target]!=-1:
            return dp[ind][target]
        take=sys.maxsize
        if arr[ind]<=target:
            take = 1+solve(ind,target-arr[ind],dp)
        notTake = 0+solve(ind-1,target,dp)
        dp[ind][target]=min(take,notTake)
        return dp[ind][target]
    n=len(arr)
    dp=[[-1 for _ in range(p+1)] for i in range(n+1)]
    temp=solve(n-1,p,dp)
    if temp>10**9:
        return -1
    else:
        return temp
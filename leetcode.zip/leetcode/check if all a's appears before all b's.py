class Solution(object):
    def checkString(self, s):
        char=s[0]
        for i in s:
            if ord(i)<ord(char):
                
                return False
            else:
                char=i
        return True
        """
        :type s: str
        :rtype: bool
        """
        
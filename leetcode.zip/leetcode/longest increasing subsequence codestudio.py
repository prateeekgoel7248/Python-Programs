from bisect import bisect_left
class Solution:
    def lengthOfLIS(self, nums: List[int]) -> int:
        arr=[nums[0]]
        for i in nums[1:]:
            if i>arr[-1]:
                arr.append(i)
            else:
                ind = bisect_left(arr,i)
                arr[ind]=i
        return len(arr)
        
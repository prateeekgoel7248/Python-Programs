class Solution(object):
    def findSubsequences(self, nums):
        visited=set()
        n=len(nums)
        res=[]
        def bt(i,curr,prev):
            if i==n:
                if len(curr)>1:
                    j=','.join(map(str,curr))
                    if j not in visited:
                        res.append(curr[:])
                        visited.add(j)
                return
            if nums[i]>=prev:
                bt(i+1,curr+[nums[i]],nums[i])
            bt(i+1,curr,prev)
            # pass
        bt(0,[],-101)
        return res
        """
        :type nums: List[int]
        :rtype: List[List[int]]
        """
        
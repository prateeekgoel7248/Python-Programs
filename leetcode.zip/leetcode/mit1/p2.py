def isPalindrome(s):
    i = 0
    j = len(s) - 1
    while i < j:
        if s[i] != s[j]:
            return False
        i += 1
        j -= 1
    return True


def IntList():
    lis = input().split()
    lis = list(map(int, lis))
    # print(lis)
    return lis


def StrList():
    s = input()
    lis = [val for val in s]
    # print(lis)
    return lis


def FloatList():
    lis = input().split()
    lis = list(map(float, lis))
    return lis


def solveByPRateek():
	a,b=input().split()
	a,b=int(a),int(b)
	ans=0
	for i in range(1,b+1):
	    ans=max(ans,a%i)
	print(ans)
	



    


# print("GEE")
tt = int(input())
while tt:
    tt -= 1
    solveByPRateek()

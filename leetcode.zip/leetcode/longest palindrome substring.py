class Solution(object):
    def longestPalindrome(self, s):
        maxx=1
        start=0
        if len(s) <= 1 or s == s[::-1]:
            return s
        else:
            for i in range(1,len(s)):
                odd=s[i-maxx-1:i+1]
                even=s[i-maxx:i+1]
                if odd==odd[::-1] and i-maxx-1>=0:
                    start=i-maxx-1
                    maxx=maxx+2
                elif even==even[::-1]:
                    start=i-maxx
                    maxx=maxx+1
        return s[start:start+maxx]
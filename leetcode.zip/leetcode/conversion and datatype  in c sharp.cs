using System;
using System.IO;

class MAIN  {
    public static void Main(string[] args) {
        // YOUR CODE GOES HERE
        // Please take input and print output to standard input/output (stdin/stdout)
        // DO NOT USE ARGUMENTS FOR INPUT
        // E.g. 'StreamReader' for input & 'StreamWriter' for output
        int a=Convert.ToInt32(Console.ReadLine());
        long b=Convert.ToInt64(Console.ReadLine());
        string s=Console.ReadLine();
        char c=(s[0]);
        string s1=Console.ReadLine();
        float d= float.Parse(s1);
        string s2=Console.ReadLine();
        double e;
        e = Convert.ToDouble(s2);
        System.Console.WriteLine(a);
        System.Console.WriteLine(b);
        System.Console.WriteLine(c);
        System.Console.WriteLine(d);
        System.Console.WriteLine(e);


    }
}
import math
from math import gcd, lcm
from collections import Counter, defaultdict


def isPalindrome(s):
    i = 0
    j = len(s) - 1
    while i < j:
        if s[i] != s[j]:
            return False
        i += 1
        j -= 1
    return True


def IntList():
    lis = input().split()
    lis = list(map(int, lis))
    # print(lis)
    return lis


def StrList():
    s = input()
    lis = [val for val in s]
    # print(lis)
    return lis


def FloatList():
    lis = input().split()
    lis = list(map(float, lis))
    return lis


def SolveByPrateek():
    n=int(input())
    pan=IntList()
    count=0
    if pan[0]<=pan[-1]:
        count+=1
        tmp=pan[0]
        pan.pop(0)
        while len(pan):
            if pan[0]<=pan[-1]:
                if pan[0]>=tmp:
                    count+=1
                    tmp=pan[0]
                    pan.pop(0)
                else:
                    pan.pop(0)
            else:
                if pan[-1]>=tmp:
                    count+=1
                    tmp=pan[-1]
                    pan.pop()
                else:
                    pan.pop()
    else:
        count += 1
        tmp = pan[0]
        pan.pop(0)
        while len(pan):
            if pan[0] <= pan[-1]:
                if pan[0] >= tmp:
                    count += 1
                    tmp = pan[0]
                    pan.pop(0)
                else:
                    pan.pop(0)
            else:
                if pan[-1] >= tmp:
                    count += 1
                    tmp = pan[-1]
                    pan.pop()
                else:
                    pan.pop()
    print(count)
        
                




CodeJamCode = int(input())
for i in range(1, CodeJamCode + 1):
    print(f"Case #{i}:", end=" ")
    SolveByPrateek()

# Definition for a binary tree node.
class TreeNode(object):
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right


class Solution(object):
    def buildTree(self, inorder, postorder):
        d = dict()
        for i in range(len(inorder)):
            d[inorder[i]] = i
        return self.solve(postorder, 0, len(postorder) - 1, inorder, 0, len(inorder) - 1, d)

    def solve(self, postorder, postStart, postEnd, inorder, inStart, inEnd, d):
        if postStart > postEnd or inStart > inEnd:
            return None
        root = TreeNode(postorder[postEnd])
        ind = d[root.val]
        eleCount = ind - inStart
        root.left = self.solve(postorder, postStart, postStart + eleCount - 1, inorder, inStart, ind - 1, d)
        root.right = self.solve(postorder, postStart + eleCount, postEnd - 1, inorder, ind + 1, inEnd, d)
        return root

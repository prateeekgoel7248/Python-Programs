class DPSolution:
    def findLongestChain(self, pairs: List[List[int]]) -> int:       
        dp = [1 for _ in range(len(pairs))]
        
        pairs = sorted(pairs, key = lambda x: x[0])
        
        for i in range(1, len(pairs)):
            for j in range(i):
                if pairs[i][0] > pairs[j][1]:
                    dp[i] = max(dp[i], 1 + dp[j])
        return dp[-1]

    
class GreedySolution:
    def findLongestChain(self, pairs):      
        count, curr = 0, -float("inf")
        
        pairs = sorted(pairs, key = lambda x: x[1])
        
        for x, y in pairs:
            if curr < x:  # compare the prior right with left
                count += 1
                curr = y   # set to right  
        
        return count
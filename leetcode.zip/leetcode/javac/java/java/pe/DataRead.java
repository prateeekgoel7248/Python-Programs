import java.io.*;

class DataRead {
	public static void main(String[] args) {
		Student s;
		try {
			FileInputStream fIn = new FileInputStream("Object");
			ObjectInputStream objIn = new ObjectInputStream(fIn);
			s = (Student) objIn.readObject();
			System.out.println(s.getName());
			System.out.println(s.getRoll());
		} 
		catch(Exception ex) {
			System.out.println(ex);
		}

	}
}
class Solution(object):
    def longestStrChain(self, words):
        buckets = {}
        
        for word in words:
            length = len(word)
            if length in buckets:
                buckets[length].append(word)
            else:
                buckets[length] = [word]
                
        lengths = list(buckets.keys())
        lengths.sort()
        
        dp = {word: 1 for word in buckets[lengths[0]]}
                
        def findChainLength(word):
            length = len(word)
            
            if (length - 1) not in buckets:
                dp[word] = 1
                return
            
            max_chain_length = 0
            
            for idx_to_remove in range(length):
                subword = word[:idx_to_remove] + word[idx_to_remove+1:]
                if subword in dp:
                    chain_length = dp[subword] + 1
                    max_chain_length = max(max_chain_length, chain_length)
                    
            if max_chain_length == 0:
                dp[word] = 1
            else:
                dp[word] = max_chain_length
                
        max_chain_len = 1
        
        for length in lengths[1:]:
            for word in buckets[length]:
                findChainLength(word)
                max_chain_len = max(max_chain_len, dp[word])
                
        return max_chain_len

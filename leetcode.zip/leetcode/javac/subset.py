import copy
from copy import copy,deepcopy
class Solution:
    # @param A : list of integers
    # @return a list of list of integers
    def solver_helper(self,input, output,result):
        
        if (len(input)==0):
            #at leaf node append to output
            result.append(output)
            return

        op1=deepcopy(output)
        op2=deepcopy(output)
        op2.append(input[0])
        self.solver_helper(input[1:],op1,result)
        self.solver_helper(input[1:],op2,result)
            
    def subsets(self, nums):
        nums.sort()
        """
        :type nums: List[int]
        :rtype: List[List[int]]
        """
               
            
        input=nums
        result,output=[],[]
        self.solver_helper(input, output,result)
        # print(result)
        return sorted(result)


















#approach 2
        res = []
        subset = []
        def dfs(i):
            if i >= len(nums):
                res.append(subset.copy())
                return
            subset.append(nums[i])
            dfs(i + 1)
            subset.pop()
            dfs(i + 1)
        dfs(0)
        return res
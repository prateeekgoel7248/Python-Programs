import java.io.*;  
class WrDemo{
	public static void main(String [] args){
		
		BufferedReader bReader = new BufferedReader(new InputStreamReader(System.in));
		try{
			int c;
			while((char)(c=bReader.read())!='!')
			{
				System.out.print((char)c);
			}
			throw new IOException();
		}
	catch(Exception ex){
		System.out.println("\nIt is because of data can be of any type");
		System.out.println(ex);
	}
	}
}

/*
public static parseInt(String abc) throws NumberFormatException
{

}
*/
 
import java.io.*;
class Pg{
	public static void main(String[] args) throws FileNotFound{
		BufferReader b = new BufferReader(new InputStreamReader(System.in));
		try{

			// Reader obj = new InputStreamReader(System.in);
			// System.out.println("Enter the data into the file : ");

			// FileInputStream fR = new FileInputStream("text.txt");
			FileOutputStream fW = new FileOutputStream("text2.txt");

			int c=0;
			while((char)(c=b.read())!='!'){
				fW.write(c);
				System.out.println((char)c);
			}
			fW.close();

		}
		catch(Exception ex){
			System.out.println(ex);
		}
	}
}
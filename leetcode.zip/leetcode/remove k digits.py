class Solution(object):
    def removeKdigits(self, nums, k):
		stack = []

		# implement increasing stack
		for i in range(len(nums)):
			while stack and stack[-1] > nums[i] and len(nums) - i + len(stack) > len(nums) - k:
				stack.pop()

			stack.append(nums[i])

	
		if len(stack) > len(nums) - k:
			return str(int("".join(stack[:len(nums) - k]))) if len(nums) != k else "0"

		return str(int("".join(stack))) 

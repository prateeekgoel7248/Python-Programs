class Solution:
    def maximumEvenSplit(self, finalSum):
        if finalSum%2 != 0:
            return []
        finalSum //= 2
        ans = []
        print(finalSum)
        for i in range(1, 10**5):
            
            if finalSum-i <= i:
                # print
                ans.append(finalSum)
                break
            ans.append(i)
            finalSum -= i
        ans = [2*i for i in ans]
        # ans.sort()
        return ans
obj=Solution()
print(obj.maximumEvenSplit(28))
class Solution(object):
    def poorPigs(self, buckets, minutesToDie, minutesToTest):
        round = minutesToTest//minutesToDie + 1
        # print(round)
        low=0
        high=10
        while low<high:
            m = low+(high-low)//2
            if (round ** m) <buckets:
                low=m+1
            else:
                high=m
        return low        
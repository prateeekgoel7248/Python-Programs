class Solution:
	# @param A : list of integers
	# @param B : list of integers
	def merge(self, A, B):
        m=len(A)
        n=len(B)
        i=m-1
        j=n-1
        for k in range(n):
            A.append(0)
        while i>=0 and j>=0:
            if A[i]<B[j]:
                A[i+j+1]=B[j]
                j-=1
            else:
                A[i+j+1]=A[i]
                i-=1


#A : [ 1, 2 ]
#B : [ -1, 2 ]
                # for this test case we are using this while loop because if i is -1 and j is 0 then the first while loop terminates and we have to add the first b array element into the A array to givee correct output so we use this new while loop.
                
        while j>=0:
            A[j]=B[j]
            j-=1


                

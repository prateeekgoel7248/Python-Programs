class Solution(object):
    def maxProduct(self, nums):
        curr=1
        import sys
        ans=-(sys.maxsize)
        for i in nums:
            curr*=i
            ans=max(ans,curr)
            if curr==0:
                curr=1
        curr=1
        for i in nums[::-1]:
            curr*=i
            ans=max(ans,curr)
            if curr==0:
                curr=1
        return ans
        
            
        # locMin = locMax = glo = nums[0]
        # for num in nums[1:]:
        #     locMin, locMax= min(locMin*num, num, locMax*num), max(locMin*num, num, locMax*num)
        #     glo = max(glo, locMax)
        # return glo
# in this we are taking the left array max and right array max and finding the final max using both of them.
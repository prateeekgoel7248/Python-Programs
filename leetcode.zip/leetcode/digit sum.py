def cnt(num,n,tight):
	if tight==0:
		return pow(10,n)
	if n==0:
		return 1
	number = 0
	ub=int(num[len(num)-n])
	for dig in range(0,ub+1):
		number+=cnt(num,n-1,tight&(ub==dig))
	return number
	
def solve(num,n,tight):
	#where num is the number given and n is the lenght of the number or we can say the count of digit and tight means that left most element can be bigger or less than that number
	if n==0:
		return 0
	if dp[n][tight]!=-1:
		return dp[n][tight]
	ub=int(num[len(num)-n]) if tight else 9
	#most important thing to remember
	total=0
	for dig in range(0,ub+1):
		total+=(dig*cnt(num,n-1,tight&(ub==dig)))
		total+=solve(num,n-1,tight&(ub==dig))
	dp[n][tight]=total
	return dp[n][tight]

	

dp=[[-1]*2]*20
t=int(input())
while t:
	t-=1
	L,R=input().split()
	L=int(L)-1
	#we are doing l-1 because for l=4 and r=9 we calculate the sum for 9 first and then we calculate the sum for l-1=3 and then subtract so it  will consider for 4 also and if we take l=4 only then it will discard the sum 4

	L=str(L)
	print(dp)
	Rans=solve(R,len(R),1)
	dp=[[-1]*2]*20
	Lans=solve(L,len(L),1)
	print(Rans-Lans)





# Definition for a binary tree node.
# class TreeNode(object):
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution(object):
    def invertTree(self, root):
        stack = [root]
        # print(stack)
        while stack:
            node = stack.pop()
            
            if node:
                print(node.val)
                node.left, node.right = node.right, node.left
                stack += node.left, node.right
                # print(stack)
        return root
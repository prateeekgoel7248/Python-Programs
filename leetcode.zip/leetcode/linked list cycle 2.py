# Definition for singly-linked list.
# class ListNode(object):
#     def __init__(self, x):
#         self.val = x
#         self.next = None

class Solution(object):
    def detectCycle(self, head):
        
        slow=head
        fast=head
        while fast and fast.next:
            slow=slow.next
            fast=fast.next.next
            if slow==fast:
                break
        if fast == None or fast.next == None:
            return None
        slow=head
        while slow!=fast:
            slow=slow.next
            fast=fast.next
        return slow
    
    
    #lets say the length of the cycle is l1+l2
    #so total length will be l1+l2+lc
    #so lets assume that the length where the cycle gets know that there is a cycle will be l1+l2
    #and lc is the length which we have to cover to complete the cycle or to reach the first node of the cycle.
    
        
        
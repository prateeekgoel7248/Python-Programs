# Definition for singly-linked list.
# class ListNode:
#     def __init__(self, x):
#         self.val = x
#         self.next = None

class Solution:
    # @param A : head node of linked list
    # @return the head node in the linked list
    def insertionSortList(self, head):
        dummy=ListNode(0)
        dummy.next=head
        
        #head is the tail node of the sorted list (may sound confused)
        while head.next:
            
            #the node to be compared
            current=head.next
            
            #find the insertion position
            temp=dummy
            while temp.next is not current and temp.next.val<=current.val:
                temp=temp.next   
            
            #the insertion position is after the tail of the sorted list
            #which means the node stays put, it becomes "head"
            if temp.next is current:
                head=head.next
                
            #do insertion
            else:
                head.next=current.next
                current.next=temp.next
                temp.next=current
                
        return dummy.next
class Solution:
	# @param A : tuple of integers
	# @return an integer
	def lis(self, A):
        t=[1 for i in range(len(A))]
        if len(A)==1:
            return 1
        ans=0
        for i in range(1,len(A)):
            for j in range(i):
                if A[i]>A[j]:
                    t[i]=max(t[i],1+t[j])
            ans=max(ans,t[i])
        return ans
        
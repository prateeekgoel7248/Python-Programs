import heapq
class Solution:
    def mergeKLists(self, lists: List[Optional[ListNode]]) -> Optional[ListNode]:
        pqueue=[]
        dummy=tail=ListNode(0)
        for ind,item in enumerate(lists):
            if item:
                heapq.heappush(pqueue,(item.val,ind))
        while pqueue:
            tmp=heapq.heappop(pqueue)
            tail.next=ListNode(tmp[0])
            tail=tail.next
            if lists[tmp[1]].next:
                lists[tmp[1]]=lists[tmp[1]].next
                heapq.heappush(pqueue,(lists[tmp[1]].val,tmp[1]))
        return dummy.next
#User function Template for python3


class Solution:
    
    def getMaxArea(self,histogram):
        #code here
        def nsr(arr):
            # n=len(arr)
            s=[]
            res=[]
            # size=[i for i in range(len(arr))]
            # size=size[::-1]
            for i in range(len(arr)-1,-1,-1):
                # print(i)
                while len(s)>0 and arr[i]<=s[-1][0]:
                    s.pop()
                if len(s)==0:
                    res.append(len(arr))
                else:
                    res.append(s[-1][1])
                s.append([arr[i],i])
            res.reverse()
            return res
        def nsl(arr):
            # n=len(arr)
            s=[]
            res=[]
            # size=[i for i in range(len(arr))]
            for i in range(len(arr)):
                # print(i)
                while len(s)>0 and arr[i]<=s[-1][0]:
                    s.pop()
                if len(s)==0:
                    res.append(-1)
                else:
                    res.append(s[-1][1])
                s.append([arr[i],i])
            return res
            
        right = nsr(histogram)
        left = nsl(histogram)
        # print(right)
        # print(left)
        # print(histogram)
        # ans =[]
        maxi=0
        # for i,j in zip(left,right):
        #     ans.append(j-i-1)
        # for i,j in zip(ans,histogram):
        #     maxi.append(i*j)
        for i in range(len(histogram)):
            temp=(histogram[i]*(right[i]-left[i]-1))
            if maxi<temp:
                maxi=temp
        # print(max(ans))
        return maxi
#{ 
#  Driver Code Starts
#Initial Template for Python 3

# by Jinay Shah 

if __name__ == '__main__':
    test_cases = int(input())
    for cases in range(test_cases) :
        n = int(input())
        a = list(map(int,input().strip().split()))
        ob=Solution()
        print(ob.getMaxArea(a))
# } Driver Code Ends
class Solution:
	def floodFill(self, image, sr, sc, newColor):
		n=len(image)
		m=len(image[0])
		color = image[sr][sc]
		visited=[[0 for _ in range(m)] for i in range(n)]
		def dfs(i,j):
			if i<0 or i>=n or j<0 or j>=m:
				return 0
			if image[i][j] == newColor or image[i][j] != color:
                return
			if not visited[i][j]:
				visited[i][j]=1
				image[i][j]=newColor
				dfs(i,j-1)
				dfs(i+1,j)
				dfs(i,j+1)
				dfs(i-1,j)
                
		dfs(sr,sc)
		return image
# 		r, c = len(image), len(image[0])
#         color = image[sr][sc]
#         def dfs(i, j):
#             if i < 0 or i>=r or j < 0 or j >= c:
#                 return
#             if image[i][j] == newColor or image[i][j] != color:
#                 return
#             image[i][j] = newColor
#             dfs(i+1, j)
#             dfs(i-1, j)
#             dfs(i,j+1)
#             dfs(i, j-1)
#         dfs(sr, sc)
#         return image


#{ 
 # Driver Code Starts
import sys
sys.setrecursionlimit(10**7)
if __name__ == '__main__':

	T=int(input())
	for i in range(T):
		n, m = input().split()
		n = int(n)
		m = int(m)
		image = []
		for _ in range(n):
			image.append(list(map(int, input().split())))
		sr, sc, newColor = input().split()
		sr = int(sr); sc = int(sc); newColor = int(newColor);
		obj = Solution()
		ans = obj.floodFill(image, sr, sc, newColor)
		for _ in ans:
			for __ in _:
				print(__, end = " ")
			print()
# } Driver Code Ends
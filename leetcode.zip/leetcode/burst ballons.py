#memoization

class Solution(object):
    def solve(self,i,j,cost,dp):
        if i>j:
            return 0
        if dp[i][j]!=-1:
            return dp[i][j]
        maxi=-sys.maxsize
        for ind in range(i,j+1):
            temp = cost[i-1]*cost[ind]*cost[j+1]+self.solve(i,ind-1,cost,dp)+self.solve(ind+1,j,cost,dp)
            maxi=max(maxi,temp)
        dp[i][j]=maxi
        return maxi
    def maxCoins(self, nums):
        n=len(nums)
        dp=[[-1 for _ in range(n+1)]for i in range(n+1)]
        nums.append(1)
        nums.insert(0,1)
        return self.solve(1,n,nums,dp)
    
        
        """
        :type nums: List[int]
        :rtype: int
        """
        



#tabulation
#which is very much optimal

class Solution(object):
    def solve(self,i,j,cost,dp):
        if i>j:
            return 0
        if dp[i][j]!=-1:
            return dp[i][j]
        maxi=-sys.maxsize
        for ind in range(i,j+1):
            temp = cost[i-1]*cost[ind]*cost[j+1]+self.solve(i,ind-1,cost,dp)+self.solve(ind+1,j,cost,dp)
            maxi=max(maxi,temp)
        dp[i][j]=maxi
        return maxi
    def maxCoins(self, cost):
        n=len(cost)
        dp=[[0 for _ in range(n+2)]for i in range(n+2)]
        cost.append(1)
        cost.insert(0,1)
        
        for i in range(n,0,-1):
            for j in range(1,n+1):
                if i>j:
                    continue
                maxi=-sys.maxsize
                for ind in range(i,j+1):
                    temp = cost[i-1]*cost[ind]*cost[j+1]+dp[i][ind-1]+dp[ind+1][j]
                    maxi=max(maxi,temp)
                dp[i][j]=maxi
        return dp[1][n]
        
        
        
        # return self.solve(1,n,nums,dp)
    
        
        """
        :type nums: List[int]
        :rtype: int
        """
        
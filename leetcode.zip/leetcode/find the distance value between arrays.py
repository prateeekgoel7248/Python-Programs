class Solution(object):
    def findTheDistanceValue(self, arr1, arr2, d):
        
        if d == 0:
            return 0
        ret = 0
        arr2 = sorted(arr2)
        for num in arr1:
            lo, hi = 0, len(arr2) - 1
            valid = True
            while lo <= hi:
                mid = lo + (hi - lo) // 2
                if arr2[mid] == num or abs(num - arr2[mid]) <= d:
                    valid = False
                    break
                elif arr2[mid] < num:
                    lo = mid + 1
                else:
                    hi = mid - 1
            ret += valid
        return ret
class Solution(object):
    def climbStairs(self, n):
        if n < 3:
            return n
			
		# Next, for dynamic programming solutions, we often want to have a goal in mind.
		# The goal is to find the number of permutations or possible ways to step up to a given n. Getting to N is the end goal here.
        # So we need a place to store the results of our subsequences up towards our goal of N. We can think that we have small goals starting
		# at 0, 1, 2, 3, 4... up to N that we want to calculate.
        
        possibleStepPaths = [ 0 for i in range(0, n + 1) ]
        
        possibleStepPaths[0] = 0
        possibleStepPaths[1] = 1
        possibleStepPaths[2] = 2
        
		# Iterate through our goals:
		# We want to build up an answer for the target of N. To do that, we can calculate the number of possible step paths one can take for 3, 4, 5.. up to N iteratively, one at a time, and storing the result of each subgoal back into our possibleStepPaths[subgoal].
		
        for i in range(3, n + 1):
		
            # Get the existing previously calculated subgoals that are accessible from i (think of 1 tile back or 2 tiles back from index i).
			# Remember that we have fed the start of our subgoals array with values so that we can build up from i:
			
            subSteps = [ possibleStepPaths[j] for j in range(i-2, i-1 + 1) ]
            
            # We want the sum of the possible solutions found for 1 step and 2 steps before destination i, our current subgoal.
			# This sum then represents the total number of step paths one can take for the subgoal i. We store this in possibleStepPaths and continue to our next subgoal.
            possibleStepPaths[i] = sum(subSteps)
         # Now all we have to do is pluck out the total number of step paths to get to our final goal, n:
        return possibleStepPaths[n]
        
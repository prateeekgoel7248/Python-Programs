class Solution:
	# @param A : list of strings
	# @return a strings
	def longestCommonPrefix(self, A):

        ans=""

        if(len(A)==1):

            ans=str(A[0])

            return ans;

        if len(A)==0:

            return ans;

        l=min(A)

        k=len(min(A))

        z=0

        for i in range(k):

            z=0

            for j in A:

                if j[i]==l[i]:

                    z+=1;

            if z==len(A):

                ans+=l[i];

            else:

                return ans;

        return ans;




        # m=min(len(i) for i in A)
        # print(m)
        # res=""
        # for i in range(len(A)-1):
        #     # if A[i]
        #     res=""
        #     i=0
        #     while j<m:
        #         if A[i][j]==A[i+1][j]:
        #             res+=A[i][j]
        #         j+=1



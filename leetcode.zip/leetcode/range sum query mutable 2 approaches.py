class NumArray:

    def __init__(self, nums: List[int]):
        
        self.nums = nums
        self.sums = sum(nums)

    def update(self, index, val):
        self.sums += val-self.nums[index]
        self.nums[index] = val

    def sumRange(self, left, right):
        return sum(self.nums[left:right+1]) if right-left < len(self.nums)//2 else self.sums - sum(self.nums[:left]) - sum(self.nums[right+1:])

# Your NumArray object will be instantiated and called as such:
# obj = NumArray(nums)
# obj.update(index,val)
# param_2 = obj.sumRange(left,right)











class NumArray(object):

    def __init__(self, nums):
        self.length = len(nums)
        self.seg=[0 for _ in range(len(nums)*4)]
        self.build(0,0,len(nums)-1,nums)
        """
        :type nums: List[int]
        """
    def build(self,ind,low,high,arr):
        if low==high:
            self.seg[ind]=arr[low]
            return 
        mid = (low+high)//2
        self.build(2*ind+1,low,mid,arr)
        self.build(2*ind+2,mid+1,high,arr)
        self.seg[ind]=self.seg[2*ind+1]+self.seg[2*ind+2]

    def update(self, index, val):
        return self.improve(0,0,self.length-1,index,val)
        
    def improve(self,ind,low,high,i,val):
        if low==high:
            self.seg[ind]=val
            return
        mid=(low+high)//2
        if i<=mid:
            self.improve(2*ind+1,low,mid,i,val)
        else:
            self.improve(2*ind+2,mid+1,high,i,val)
        self.seg[ind]=self.seg[2*ind+1]+self.seg[2*ind+2]
        
        

    def sumRange(self, left, right):
        return self.query(0,0,self.length-1,left,right)
        
    def query(self,ind,low,high,l,r):
        if r<low or l>high:
            return 0
        if low>=l and r>=high:
            return self.seg[ind]
        mid=(low+high)//2
        left = self.query(2*ind+1,low,mid,l,r)
        right = self.query(2*ind+2,mid+1,high,l,r)
        return left+right
    
        """
        :type left: int
        :type right: int
        :rtype: int
        """
        


# Your NumArray object will be instantiated and called as such:
# obj = NumArray(nums)
# obj.update(index,val)
# param_2 = obj.sumRange(left,right)
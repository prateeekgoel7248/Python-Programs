import sys
sys.setrecursionlimit(10**7)

def minSumPath(grid):
    # Write your code here.
    def solve(i,j,dp):
        if i==0 and j==0:
            return grid[i][j]
        if i<0 or j<0:
            return sys.maxsize
        if dp[i][j]!=-1:
            return dp[i][j]
        dp[i][j]=grid[i][j]+min(solve(i-1,j,dp),solve(i,j-1,dp))
        return dp[i][j]
    m=len(grid)
    n=len(grid[0])
    dp=[[-1 for _ in range(n+1)]for i in range(m+1)]
    return solve(m-1,n-1,dp)

# Main.
t = int(input())
while (t > 0):
    l = list(map(int, input().split()))
    n,m = l[0], l[1]
    grid = []
    for i in range(n):
        ll = list(map(int, input().split()))
        grid.append(ll)
    print(minSumPath(grid))
    t -= 1
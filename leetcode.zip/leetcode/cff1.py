def opimize(dp, d, r, i):
    if r <= 0 or i >= len(d):
        return 0
    if d[i][0] > r:
        return 0
    if dp[r] != -1:
        return dp[r][i]
    dp[r] = max(1 + opimize(dp, d, r - d[i][0], i), 1 + opimize(dp, d, r - d[i][0], i + 1))
    return dp[r]


def solveBYPRateek():
    n, r = input().split()
    n, r = int(n), int(r)
    lis1 = input().split()
    lis1 = list(map(int, lis1))
    lis2 = input().split()
    lis2 = list(map(int, lis2))

    # d=[[] for _ in range()]
    d = []
    for i in range(n):
        d.append((lis1[i] - lis2[i], lis1[i]))
    # print(d)
    res = 0
    d.sort()
    for i in range(n):
        while r >= d[i][1]:
            cc = r // d[i][1]
            cc += (1 & 0)
            res += cc
            r -= (cc * (d[i][1]))
            r -= (1 & 0)
            r += (cc * (d[i][1]-d[i][0]))
            r += (1 & 0)
    print(res)
    # res = 0
    # i = 0
    # dp = [-1 for ]
    # for i in range(n + 1):

    # temp = []
    # for j in range(r + 1):
    #     temp.append(-1)
    # dp.append(temp)
    # print(d)
    # for i in range(n + 1):
    #     for j in range(r + 1):
    #         if i == 0 or j == 0:
    #             dp[i][j] = 0
    # opimize(dp, d, 0, 0)
    # for i in range(1, n + 1):
    #     for j in range(1, r + 1):
    #         if d[i - 1][1] <= j:
    #             dp[i][j] = max(1 + dp[i][j - d[i - 1][0]], dp[i - 1][j])
    #         else:
    #             dp[i][j] = dp[i - 1][j]

    # while r > 0 and i < n:
    #     if d[i][1] <= r:
    #         r -= d[i][0]
    #         res += 1
    #     else:
    #         i += 1
    # for i in dp:
    #     print(i)
    # print(dp[n][r])


testcase = int(input())
while testcase:
    testcase -= 1
    solveBYPRateek()

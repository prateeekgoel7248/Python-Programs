class Solution(object):
    def solve(self,move,m,n,i,j,cnt,dp): 
        
        if i>=m or j>=n or i<0 or j<0:
            return 1
        if move==0:
            return 0
        if dp[i][j][move]!=-1:
            return dp[i][j][move]
        dp[i][j][move]= self.solve(move-1,m,n,i-1,j,cnt,dp)+self.solve(move-1,m,n,i+1,j,cnt,dp)+self.solve(move-1,m,n,i,j+1,cnt,dp)+self.solve(move-1,m,n,i,j-1,cnt,dp)
        return dp[i][j][move]
        
    def findPaths(self, m, n, maxMove, startRow, startColumn):
        dp=[[[-1 for j in range(maxMove+1)] for _ in range(n+1)]for i in range(m+1)]
        # print(dp)
        return self.solve(maxMove,m,n,startRow,startColumn,0,dp)%((10**9)+7)
        """
        :type m: int
        :type n: int
        :type maxMove: int
        :type startRow: int
        :type startColumn: int
        :rtype: int
        """
        
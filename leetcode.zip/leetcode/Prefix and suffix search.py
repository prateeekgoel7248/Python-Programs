class WordFilter:

        def __init__(self, words: List[str]):
            self.hashmap = dict()
            num_words = len(words)
            for word_idx in range(num_words):
                word = words[word_idx]
                word_len = len(word)
                for start_idx in range(1,word_len+1):
                    prefix_part = word[:start_idx]
                    for end_idx in range(word_len-1,-1,-1): 
                        suffix_part = word[end_idx:word_len]
                        self.hashmap[(prefix_part, suffix_part)] = word_idx

        def f(self, prefix: str, suffix: str) -> int:
            if (prefix, suffix) in self.hashmap:
                return self.hashmap[(prefix, suffix)]
            return -1


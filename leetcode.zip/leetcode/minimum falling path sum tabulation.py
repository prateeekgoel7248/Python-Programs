class Solution:
    def minFallingPathSum(self, matrix: List[List[int]]) -> int:
        import sys
        dp=[[0 for _ in range(len(matrix[0]))]for i in range(len(matrix))]
        dp[0]=matrix[0]
        for i in range(1,len(matrix)):
            for j in range(len(matrix[0])):
                s=matrix[i][j]+dp[i-1][j]
                ld=rd=matrix[i][j]
                ld+=dp[i-1][j-1] if j-1>=0 else sys.maxsize
                rd+=dp[i-1][j+1] if j+1<len(matrix[0]) else sys.maxsize
                dp[i][j]=min(s,ld,rd)

        return min(dp[len(matrix)-1])

        
        
        # return min(f(len(matrix)-1,k) for k in range(len(matrix[0])))
        
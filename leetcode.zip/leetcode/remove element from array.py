class Solution:
    # @param A : list of integers
    # @param B : integer
    # @return an integer
    def removeElement(self, A, B):
	#just an simple solution try to dry run for
	#[4,1,1,2,3] for  B =1 and you will understand everything

        i=-1
        n=len(A)
        for j in range(len(A)):
            if A[j]!=B:
                i+=1
                A[i],A[j]=A[j],A[i]
        return i+1
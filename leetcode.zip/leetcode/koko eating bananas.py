#just an simple question

class Solution:
    def minEatingSpeed(self, piles: List[int], h: int) -> int:
        def valid(k):
            s=0
            for i in piles:
                s+=(i+k-1)//k
            return s<=h
        start=1
        end=max(piles)
        res=-1
        while start<=end:
            mid=start+(end-start)//2
            if valid(mid):
                res=mid
                end=mid-1
            else:
                start=mid+1
        return res
            
        
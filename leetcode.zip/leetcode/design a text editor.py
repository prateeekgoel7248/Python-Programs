#APPROACH 1 - USING STRING BASIC's

class TextEditor:
    def __init__(self):
        self.string = ""
        self.cursor = 0

    def addText(self, text: str) -> None:
        prefix = self.string[:self.cursor]
        suffix = self.string[self.cursor:]
        self.string = prefix + text + suffix
        self.cursor += len(text)

    def deleteText(self, k: int) -> int:
        prefix = self.string[:self.cursor]
        suffix = self.string[self.cursor:]
        shift = min(k, len(prefix))
        self.string = prefix[:-shift] + suffix
        self.cursor -= shift
        return shift

    def near(self) -> str:
        return self.string[self.cursor - min(10, self.cursor) : self.cursor]

    def cursorLeft(self, k: int) -> str:
        shift = min(k, self.cursor)
        self.cursor -= shift
        return self.near()

    def cursorRight(self, k: int) -> str:
        shift = min(k, len(self.string) - self.cursor)
        self.cursor += shift
        return self.near()



#APPROACH - USING TWO STACKS's 
1ST STACK FOR  THE LEFT OF THE CURSOR AND 2ND STACK FOR THE RIGHT OF THE CURSOR
#PROVIDE MORE SPEED THEN BASIC STRING 
class TextEditor:
    def __init__(self):
        self.stack1=[]
        self.stack2=[]

    def addText(self, text: str) -> None:
        for i in text:
            self.stack1.append(i)

    def deleteText(self, k: int) -> int:
        c=0
        while self.stack1 and k:
            self.stack1.pop()
            k-=1
            c+=1
        return c

    def cursorLeft(self, k: int) -> str:
        while self.stack1 and k:
            self.stack2.append(self.stack1.pop())
            k-=1
        n=len(self.stack1)
        mi=min(10,n)
        return ''.join(self.stack1[n-mi:n])

    def cursorRight(self, k: int) -> str:
        while self.stack2 and k:
            self.stack1.append(self.stack2.pop())
            k-=1
        n=len(self.stack1)
        mi=min(10,n)
        return ''.join(self.stack1[n-mi:n])
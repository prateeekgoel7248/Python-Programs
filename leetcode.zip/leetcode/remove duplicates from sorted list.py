# Definition for singly-linked list.
# class ListNode(object):
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution(object):
    def deleteDuplicates(self, head):
        fakehead = ListNode(0, head)
        pred=fakehead
        while head:
            if head.next and head.val==head.next.val:
                while head.next and head.val==head.next.val:
                    head=head.next
                pred.next=head.next
		#here pred just pointing to next value, it is not storing the next value because we are not updating the pred we are just taking that it is  pointing to the next element.
            else: pred=pred.next
            head=head.next
        return fakehead.next
        # :type head: ListNode
        # :rtype: ListNode
        # """
        
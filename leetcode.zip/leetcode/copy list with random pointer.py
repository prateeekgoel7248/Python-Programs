"""
# Definition for a Node.
class Node:
    def __init__(self, x, next=None, random=None):
        self.val = int(x)
        self.next = next
        self.random = random
"""

class Solution(object):
    def copyRandomList(self, head):
        if head==None:
            return None
        curr=head
#         inserting the new nodes in between
        while curr:
            temp=curr.next
            curr.next=Node(curr.val)
            curr.next.next=temp
            curr=temp
        curr=head
#         setting random pointers to new nodes
        while curr:
            if curr:
                curr.next.random=curr.random.next if curr.random else None
            curr=curr.next.next
        orig=head
        copy=head.next
        temp=copy
        while orig:
            orig.next=orig.next.next
            copy.next=copy.next.next if copy.next else copy.next
            orig=orig.next
            copy=copy.next
        return temp
                
        # return head
        """
        :type head: Node
        :rtype: Node
        """
        
#in this we are making the new node which is pointing to the data of the nodes and then making some links 
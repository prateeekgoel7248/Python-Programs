class Solution(object):
    def solve(self,index,s,path,res):
        if index==len(s):
            res.append(path)
            return
        for i in range(index,len(s)):
            if self.isPalindrome(s[index:i+1]):
                self.solve(i+1,s,path+[s[index:i+1]],res)
        
                
    def isPalindrome(self,s):
        i=0
        j=len(s)-1
        while i<j:
            if s[i]!=s[j]:
                return False
            i+=1
            j-=1
        return True
    def partition(self, s):
        res=[]
        path=[]
        self.solve(0,s,path,res)
        return res
        

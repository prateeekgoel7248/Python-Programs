class Solution(object):
    def distributeCandies(self, C):
        
        return min(len(set(C)), len(C) // 2)
        """
        :type candyType: List[int]
        :rtype: int
        """
        
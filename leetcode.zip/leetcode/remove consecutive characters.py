class Solution:
    def solve(self, s, k):
        i = 0
        a = []
        while i < len(s):
            a.append(s[i])
            while i+1 < len(s) and s[i] == s[i+1]:
                a[-1] += s[i]
                i += 1
            i += 1

        ns = ""
        for ccs in a:
            final_len = len(ccs)%k
            ns += ccs[0]*final_len
        
        return ns
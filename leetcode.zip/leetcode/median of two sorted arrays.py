import sys
def median(nums1, nums2):
    # Write the function here.
    #nums1 should be minimum because we are reducing the search space if we are using the num1
        if len(nums2)<len(nums1): return median(nums2,nums1)
        n1= len(nums1)
        n2=len(nums2)
        low=0
        high=n1
        count = (n1+n2+1)//2
        #it is counting the total element required for left side
        mn=-sys.maxsize
        mx=sys.maxsize
        while low<=high:
            cut1=(low+high)//2
            cut2 = count - cut1
            #if arr1 is fully taken then there is nothing left for right so we take max and it is same for arr2
            #if arr1 is nothing taken then its left doestn;t contain anything so we give -sys.maxsize as minimum- same for arr2 also
            
            l1= mn if cut1==0 else nums1[cut1-1]
            l2= mn if cut2==0 else nums2[cut2-1]
            
            r1= mx if cut1==n1 else nums1[cut1]
            r2= mx if cut2==n2 else nums2[cut2]
            
            if l1<=r2 and l2<=r1:
                if(n1+n2)%2==0:
                    return (max(l1,l2)+min(r1,r2))/2.0
                else:
                    return max(l1,l2)/1
            elif l1>r2:
                high = cut1-1
            else:
                low=cut1+1
        return 0.0
            
            
        
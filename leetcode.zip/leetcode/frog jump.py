from typing import *
import sys

  
def frogJump(n: int, heights: List[int]) -> int:

    # Write your code here.
    def solve(n,dp):
        if n==0:
            return 0
        if dp[n]!=-1:
            return dp[n]
        second=sys.maxsize
        first = abs(heights[n-1]-heights[n])+solve(n-1,dp)
        if n>1:
            second = abs(heights[n-2]-heights[n])+solve(n-2,dp)
        dp[n]=min(first,second)
        return dp[n]
    dp=[-1 for _ in range(len(heights)+1)]
    return solve(n-1,dp)

def gcd(a,b):
    if b==0:
        return a
    return gcd(b,a%b)
t=int(input())
while t:
    t-=1
    a,b=input().split()
    a,b=int(a),int(b)
    g=gcd(a,b)
    print(g,(a*b)//g)
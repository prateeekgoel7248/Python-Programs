class Solution(object):
    def minDistance(self, s, t):
        m=len(s)
        n=len(t)
        def solve(i,j,dp):
            if i<0:
                return j+1
            if j<0:
                return i+1
            if dp[i][j]!=-1:
                return dp[i][j]
            if s[i]==t[j]:
                dp[i][j] =  solve(i-1,j-1,dp)
            #delete,insert,replace 
            else:
                dp[i][j] = 1+ min(solve(i-1,j,dp),solve(i,j-1,dp),solve(i-1,j-1,dp))
            return dp[i][j]
        dp=[[-1 for _ in range(n+1)] for i in range(m+1)]
        return solve(m-1,n-1,dp)
        





class Solution(object):
    def minDistance(self, s, t):
        m=len(s)
        n=len(t)
        # def solve(i,j,dp):
        #     if i<0:
        #         return j+1
        #     if j<0:
        #         return i+1
        #     if dp[i][j]!=-1:
        #         return dp[i][j]
        #     if s[i]==t[j]:
        #         dp[i][j] =  solve(i-1,j-1,dp)
        #     #delete,insert,replace 
        #     else:
        #         dp[i][j] = 1+ min(solve(i-1,j,dp),solve(i,j-1,dp),solve(i-1,j-1,dp))
        #     return dp[i][j]
        # dp=[[0 for _ in range(n+1)] for i in range(m+1)]
        mx=max(m,n)+1
        curr=[0]*mx
        prev=[0]*mx
        # return solve(m-1,n-1,dp)
        for j in range(mx):
            prev[j]=j
        # for i in range(1,m+1):
        # curr[0]=1
        # curr =prev[:]
        
        for i in range(1,m+1):
            curr[0]=i
            for j in range(1,n+1):
                if s[i-1]==t[j-1]:
                    curr[j] =  prev[j-1]
                #delete,insert,replace 
                else:
                    curr[j] = 1+ min(prev[j],curr[j-1],prev[j-1])
            prev = curr[:]
        return prev[n]
                
            
        
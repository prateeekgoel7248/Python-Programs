class Solution:
    # @param A : integer
    # @return an integer
    def solve(self, A):
        #Approach 1
        b=bin(A)
        lis=[i for i in b]
        # print(lis)
        for i in range(2,len(lis)):
            if lis[i]=='1':
                lis[i]='0'
            else:
                lis[i]='1'
        v= ''.join(lis)
        return int(v,2)

        #Approach 2
        x = 1
        while x <= A:
            x <<= 1
        x -= 1
        return x ^ A
        

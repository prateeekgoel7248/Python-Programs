class Solution:
    def furthestBuilding(self, heights: List[int], b: int, ladders: int) -> int:
        i=0
        tmp=[]
#here wee are using heap to get the min element pop from the b and and we only use height min element when the ladder is empty or we can say length of the tmp(heap) is greater than the ladders.
#just an simple question try to use dry run once
        while i<len(heights)-1:
            if heights[i]<heights[i+1]:
                d=heights[i+1]-heights[i]
                heapq.heappush(tmp,d)
                if len(tmp)>ladders:
                    b-=heapq.heappop(tmp)
                if b<0:
                    return i
            i+=1
        return i
        
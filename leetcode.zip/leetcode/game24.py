class Solution(object):
    def validopr(self,a,b):
        valid=[]
        valid.append(a+b)
        valid.append(a-b)
        valid.append(b-a)
        valid.append(a*b)
        if abs(b)>((pow(10,-9))):
            valid.append(a/b)
        if abs(a)>((pow(10,-9))):
            valid.append(b/a)
        return valid
    def isPossible(self,nums):
        if len(nums)==1:
            return abs(24.0 - nums[0])<=(pow(10,-9))
        for i in range(len(nums)):
            for j in range(len(nums)):
                if i==j:
                    continue
                first=nums[i]
                second=nums[j]
                validoperations = self.validopr(first,second)
                nextArr=[]
                for ele in validoperations:
                    nextArr=[]
                    nextArr.append(ele)
                    for a in range(len(nums)):
                        if a==i or a==j:
                            continue
                        nextArr.append(nums[a])
                    if self.isPossible(nextArr):
                        print(nextArr)
                        return True
        return False
    import itertools
    def judgePoint24(self, cards):
        return isPossible(cards)
#User function Template for python3

class Solution:
    
    #Function to return a list containing the DFS traversal of the graph.
    def dfsOfGraph(self, V, adj):
        # code here
        
        visited=[False]*V
        
        res=[]
        def dfs(edge):
            if not visited[edge]:
                res.append(edge)
                visited[edge]=True
                for n in adj[edge]:
                    dfs(n)
        dfs(0)
        return res
        
        #stack = [0]
        # while stack:
        #     val=stack.pop()
        #     if not visited[val]:
        #         res.append(val)
        #         visited[val]=True
        #         for n in adj[val][::-1]:
        #             stack.append(n)
        # return res


#{ 
 # Driver Code Starts
if __name__ == '__main__':
    T=int(input())
    while T>0:
        V,E=map(int,input().split())
        adj=[[] for i in range(V+1)]
        for i in range(E):
            u,v=map(int,input().split())
            adj[u].append(v)
            adj[v].append(u)
        ob=Solution()
        ans=ob.dfsOfGraph(V,adj)
        for i in range(len(ans)):
            print(ans[i],end=" ")
        print()
        T-=1
# } Driver Code Ends
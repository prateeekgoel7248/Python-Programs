class Solution:
    # @param A : tuple of integers
    # @return an integer
    def maximumGap(self, nums):
        n=len(nums)
        import sys
        if n<2:
            return 0
        mn=min(nums)
        mx=max(nums)
        # print(mx,mn,n-1)
        gap=((mx-mn)*1.0)/(n-1)
        # print(gap)
        if gap<1.0:
            gap=1.0
        v=[[sys.maxsize,-sys.maxsize] for _ in range(n)]
        # print(v)
        for i in range(n):
            pos=((nums[i]-mn))/gap
            # print(pos)
            v[int(pos)][0]=min(v[int(pos)][0],nums[i])
            v[int(pos)][1]=max(v[int(pos)][1],nums[i])
        pm=v[0][1]
        # print(v)
        ans=0
        for i in range(1,n):
            if v[i][0]==sys.maxsize:
                continue
            ans=max(ans,v[i][0]-pm)
            pm=v[i][1]
        return ans
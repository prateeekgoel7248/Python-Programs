import sys
from sys import stdin, setrecursionlimit
setrecursionlimit(10**7)


def getMaxPathSum(matrix):

    #   Write your code here
#     def solve(i,j,dp):
#         if j<0 or j>=len(matrix[0]):
#             return -sys.maxsize
#         if i==0:
#             return matrix[i][j]
#         if dp[i][j]!=-1:
#             return dp[i][j]
#         ls = solve(i-1,j,dp)
#         ll = solve(i-1,j-1,dp)
#         lr = solve(i-1,j+1,dp)
        
#         dp[i][j]=matrix[i][j]+max(ls,lr,ll)
#         return dp[i][j]
    dp=[[0 for _ in range(len(matrix[0]))] for i in range(len(matrix))]
#     mx=-sys.maxsize
#     for i in range(len(matrix[0])):
#         mx=max(mx,solve(len(matrix)-1,i,dp))
#     return mx
    dp[0]=matrix[0]
    for i in range(1,len(matrix)):
        for j in range(len(matrix[0])):
            ls = dp[i-1][j]
            ll=lr = -sys.maxsize
            if j>0:
                ll = dp[i-1][j-1]
            if j+1<len(matrix[0]):
                lr = dp[i-1][j+1]

            dp[i][j]=matrix[i][j]+max(ls,lr,ll)
    mx=-sys.maxsize
    for i in range(len(matrix[0])):
        mx=max(mx,dp[len(matrix)-1][i])
    return mx
            
    

























#   taking inpit using fast I/O
def takeInput() :
    n_x = stdin.readline().strip().split(" ")
    n = int(n_x[0].strip())
    m = int(n_x[1].strip())

    matrix=[list(map(int, stdin.readline().strip().split(" "))) for row in range(n)]

    return matrix, n, m


#   main
T = int(input())
while (T > 0):
    T -= 1
    matrix, n, m = takeInput()
    print(getMaxPathSum(matrix))

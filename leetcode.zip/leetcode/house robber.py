class Solution(object):
    def rob(self, nums):
        if len(nums)==0:
            return 0
        prev1=0
        prev2=0
        for i in nums:
            prev1,prev2=prev2,max(prev2,prev1+i)
        return prev2
        """
        :type nums: List[int]
        :rtype: int
        """
        
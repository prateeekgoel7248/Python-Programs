class Solution:
    def validPartition(self, nums: List[int]) -> bool:
        @lru_cache
        def solve(i):
            # print(i)
            if i<0:
                return True
            res=False
            if i>=1 and nums[i]==nums[i-1]:
                res = res or solve(i-2)
            if i>=2 and nums[i]==nums[i-1]==nums[i-2]:
                res = res or solve(i-3)
            if i>=2 and nums[i]==nums[i-1]+1==nums[i-2]+2:
                res = res or solve(i-3)
            return res
        n=len(nums)
        return solve(n-1)
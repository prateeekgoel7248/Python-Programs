# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution:
    def increasingBST(self, root: TreeNode) -> TreeNode:
        ans = self.cur = TreeNode()
        
        def inorder(node):
            if node:
				# track the left side first
                inorder(node.left)
				
				# update the new tree
                self.cur.right = TreeNode(node.val)
                self.cur = self.cur.right
				
				# track the right side then
                inorder(node.right)
        
        inorder(root)
        return ans.right
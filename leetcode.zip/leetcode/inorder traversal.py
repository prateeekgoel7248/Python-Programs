    def traversal(self, root, inorder):
        if root:
            self.traversal(root.left, inorder)
            inorder.append(root.val)
            self.traversal(root.right, inorder)
    def inorderTraversal(self, root):
        inorder = []
        self.traversal(root, inorder)
        return inorder
from typing import List
import sys
def maxCoins(a: List[int]) -> int:
	# Write your code here.
    def solve(i,j,dp):
        if i>j:
            return 0
        if dp[i][j]!=-1:
            return dp[i][j]
        mx = -sys.maxsize
        for ind in range(i,j+1):
            cost = a[i-1]*a[ind]*a[j+1]+solve(i,ind-1,dp)+solve(ind+1,j,dp)
            mx=max(mx,cost)
        dp[i][j]=mx
        return mx
        
    n=len(a)
    dp=[[0 for _ in range(n+2)] for i in range(n+2)]
    a.insert(0,1)
    a.append(1)
#     return  solve(1,n,dp)
    for i in range(n,0,-1):
        for j in range(1,n+1):
            if i>j: continue
            mx = -sys.maxsize
            for ind in range(i,j+1):
                cost = a[i-1]*a[ind]*a[j+1]+dp[i][ind-1]+dp[ind+1][j]
                mx=max(mx,cost)
            dp[i][j]=mx
    return dp[1][n]
            
            
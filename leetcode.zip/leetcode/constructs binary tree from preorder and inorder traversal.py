# Definition for a binary tree node.
class TreeNode(object):
    def __init__(self, val=0, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right


class Solution(object):
    def buildTree(self, preorder, inorder):
        d = dict()
        for i in range(len(inorder)):
            d[inorder[i]] = i
        root = self.buildingTree(preorder, 0, len(preorder) - 1, inorder, 0, len(inorder) - 1, d)
        return root

    def buildingTree(self, preorder, preStart, preEnd, inorder, inStart, inEnd, d):
        if preStart > preEnd or inStart > inEnd:
            return None
        root = TreeNode(preorder[preStart])
        # print(root.val)
        ind = d[root.val]
        eleCount = ind - inStart
        root.left = self.buildingTree(preorder, preStart + 1, preStart + eleCount, inorder, inStart, ind - 1, d)
        root.right = self.buildingTree(preorder, preStart + eleCount + 1, preEnd, inorder, ind + 1, inEnd, d)
        return root

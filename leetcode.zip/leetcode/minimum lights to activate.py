class Solution:
    # @param A : list of integers
    # @param B : integer
    # @return an integer
    def solve(self, A, B):
        n = len(A)
        curr = 0;
        count = 0;
        while(curr < n):

        # {
            next = curr+B-1;
            ind = next;
            prev = curr-B+1;
            if(prev<0):
                prev = 0
            while(ind>=prev and ind<n):
            # {
                if(A[ind]):
                    break
                ind-=1
            # }
            if(ind >= prev):
            # {
                count+=1
                curr = ind+B
            
            else:
                return -1
        # }
        return count
# }

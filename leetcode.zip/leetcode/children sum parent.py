class Solution:
    #Function to check whether all nodes of a tree have the value 
    #equal to the sum of their child nodes.
    def isSumProperty(self, root):
        if not root:
            return
        child=0
        if root.left:
            child+=root.left.data
        if root.right:
            child+=root.right.data
        if child>root.data:
            root.data = child
        else:
            if root.left:
                root.left.data = child
            elif root.right:
                root.right.data = child
        self.isSumProperty(root.left)
        self.isSumProperty(root.right)
        
        tot =0
        if root.left:
            tot+=root.left.data
        if root.right:
            tot+=root.right.data
        if root.left or root.right:
            root.data = tot
        
        # code here
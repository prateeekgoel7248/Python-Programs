# """
# This is the interface that allows for creating nested lists.
# You should not implement it, or speculate about its implementation
# """
#class NestedInteger(object):
#    def __init__(self, value=None):
#        """
#        If value is not specified, initializes an empty list.
#        Otherwise initializes a single integer equal to value.
#        """
#
#    def isInteger(self):
#        """
#        @return True if this NestedInteger holds a single integer, rather than a nested list.
#        :rtype bool
#        """
#
#    def add(self, elem):
#        """
#        Set this NestedInteger to hold a nested list and adds a nested integer elem to it.
#        :rtype void
#        """
#
#    def setInteger(self, value):
#        """
#        Set this NestedInteger to hold a single integer equal to value.
#        :rtype void
#        """
#
#    def getInteger(self):
#        """
#        @return the single integer that this NestedInteger holds, if it holds a single integer
#        Return None if this NestedInteger holds a nested list
#        :rtype int
#        """
#
#    def getList(self):
#        """
#        @return the nested list that this NestedInteger holds, if it holds a nested list
#        Return None if this NestedInteger holds a single integer
#        :rtype List[NestedInteger]
#        """

class Solution(object):
    def deserialize(self, s):
        """
        :type s: str
        :rtype: NestedInteger
        """
        ni = NestedInteger()
        
        elements = []
        is_list = False
        if s[0] == '[':
            is_list = True
        
        # Base case: if current ni is not a list return int ni
        if not is_list:
            return NestedInteger(int(s))
        
        # Parse all the elements in the current level and add to a list
        i = 1
        while i < len(s)-1:
            if s[i] == ',':
                i+=1
            elif s[i] == '[':
                # Parse list
                i+=1
                bal = 1
                cur = ['[']
                while i<len(s)-1 and bal > 0:
                    if s[i] == ']':
                        bal-=1
                    elif s[i] == '[':
                        bal+=1
                    cur.append(s[i])
                    i+=1
                elements.append(''.join(cur))
            else:
                cur = []
                while i<len(s)-1 and s[i] != ',':
                    cur.append(s[i])
                    i+=1
                elements.append(''.join(cur))
        print(elements)
        # For each parsed element, recursively call deserialize and add to the ni list
        for element in elements:
            cur_ni = self.deserialize(element)
            ni.add(cur_ni)
        return ni
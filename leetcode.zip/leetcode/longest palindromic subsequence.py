class Solution(object):
    def longestPalindromeSubseq(self, s):
        t=s[::-1]
        def solve(i,j,dp):
            if i==0 and j==0:
                if s[i]==t[j]:
                    return 1
                else:
                    return 0
            if i<0 or j<0:
                return 0
            if dp[i][j]!=-1:
                return dp[i][j]
            first=0
            second=0
            if s[i]==t[j]:
                first = 1+solve(i-1,j-1,dp)
            else:
                second  = max(solve(i-1,j,dp),solve(i,j-1,dp))
            dp[i][j]=max(first,second)
            return dp[i][j]
        n=len(s)
        dp=[[-1 for _ in range(n+1)] for i in range(n+1)]
        return solve(n-1,n-1,dp)    
        
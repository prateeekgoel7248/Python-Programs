class Solution:
    # it is for detecting the cycle
    # 2 means that we are at a node and we give the visited[node] as 2 so that we have something to tell that we are currently at this node 
    #1 means the node is visited previously so we dont have to traverse again
    #because if there is any cycle then it will be covered from the previous node
    
    #0  means that node is not visited till now and not in the processing state
    
    
    #0 not visited
    #1 processed/visited
    #2 processing
    def isCycle(self,adj,visited,cur):
        if visited[cur]==2:
            return True
        visited[cur]=2
        for i in range(len(adj[cur])):
            if visited[adj[cur][i]]!=1:
                if self.isCycle(adj,visited,adj[cur][i]):
                    return True
        visited[cur]=1
        return False
            
        
    def canFinish(self, numCourses: int, pre: List[List[int]]) -> bool:
        adj=[[] for _ in range(numCourses)]
        for i in range(len(pre)):
            adj[pre[i][0]].append(pre[i][1])
        visited=[0 for _ in range(numCourses)]
        for i in range(numCourses):
            if visited[i]==0:
                if self.isCycle(adj,visited,i):
                    return False
        return True
        
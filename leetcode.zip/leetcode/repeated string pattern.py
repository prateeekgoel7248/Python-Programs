class Solution:
    def repeatedSubstringPattern(self, s: str) -> bool:
        N = len(s)
        for idx in range(1, N//2+1):
            if N%idx==0:
                subString = s[:idx]
                if subString*(N//idx) == s:
                    return True
        return False
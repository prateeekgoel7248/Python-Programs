class Solution(object):
    def minSwaps(self, s):
        stack=0
        ans=0
        for c in s:
            if c=="[":
                stack+=1
            elif not stack:
                stack+=1
                ans+=1
                #when we are adding stack that means it will eat an ] also for a ] 
                # when we got any ] whithout any [ means we to do a swap so ans+=1
                # and we have to got a swap with a open [ and for a open we eat a 
                # ] so we are putting stack+=1 which will be reduce when we got ]
                
            else:
                stack-=1
        return ans
class Solution:
	# @param A : list of list of integers
	# @return an integer
    def getMaxArea(self,histogram):
        #code here
        def nsr(arr):
            # n=len(arr)
            s=[]
            res=[]
            # size=[i for i in range(len(arr))]
            # size=size[::-1]
            for i in range(len(arr)-1,-1,-1):
                # print(i)
                while len(s)>0 and arr[i]<=s[-1][0]:
                    s.pop()
                if len(s)==0:
                    res.append(len(arr))
                else:
                    res.append(s[-1][1])
                s.append([arr[i],i])
            res.reverse()
            return res
        def nsl(arr):
            # n=len(arr)
            s=[]
            res=[]
            # size=[i for i in range(len(arr))]
            for i in range(len(arr)):
                # print(i)
                while len(s)>0 and arr[i]<=s[-1][0]:
                    s.pop()
                if len(s)==0:
                    res.append(-1)
                else:
                    res.append(s[-1][1])
                s.append([arr[i],i])
            return res
            
        right = nsr(histogram)
        left = nsl(histogram)
        # print(right)
        # print(left)
        # print(histogram)
        # ans =[]
        maxi=0
        # for i,j in zip(left,right):
        #     ans.append(j-i-1)
        # for i,j in zip(ans,histogram):
        #     maxi.append(i*j)
        for i in range(len(histogram)):
            temp=(histogram[i]*(right[i]-left[i]-1))
            if maxi<temp:
                maxi=temp
        # print(max(ans))
        return maxi


	def maximalRectangle(self, A):
        v=[]
        for j in range(len(A[0])):
            v.append(A[0][j])
        mx= self.getMaxArea(v)
        for i in range(1,len(A)):
            for j in range(len(A[0])):
                if A[i][j]==0:
                    v[j]=0
                else:
                    v[j]=v[j]+A[i][j]
            mx=max(mx,self.getMaxArea(v))
        return mx
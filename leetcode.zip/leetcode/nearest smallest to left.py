class Solution:
    # @param A : list of integers
    # @return a list of integers
    def prevSmaller(self, A):
        res=[]
        s=[]
        for i in A:
            while len(s)>0 and i<=s[-1]:
                s.pop()
            if len(s)==0:
                res.append(-1)
            else:
                res.append(s[-1])
            s.append(i)
        return res

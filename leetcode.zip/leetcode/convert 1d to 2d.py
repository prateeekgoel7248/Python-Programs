class Solution(object):
    def construct2DArray(self, original, m, n):
        if m*n != len(original):
            return []
        
        q = []

        for i in range(0, len(original), n):
            q.append(original[i:i+n])
            
        return q
        """
        :type original: List[int]
        :type m: int
        :type n: int
        :rtype: List[List[int]]
        """
        
class Solution(object):
    def checkXMatrix(self, grid):
        i=0
        j=0
        while i<len(grid) and j<len(grid):
            if grid[i][j]==0:
                return False
            i+=1
            j+=1
        j=0
        i=len(grid)-1
        while i>=0 and j<len(grid):
            if grid[i][j]==0:
                return False
            i-=1
            j+=1
        cnt=0
        for i in range(len(grid)):
            for j in range(len(grid)):
                if grid[i][j]==0:
                    cnt+=1
        dg=0
        if len(grid)%2==0:
            dg=len(grid)*2
        else:
            dg=len(grid)*2-1
        l=len(grid)*len(grid)
        l-=dg
        return l==cnt
            
            
        """
        :type grid: List[List[int]]
        :rtype: bool
        """
        
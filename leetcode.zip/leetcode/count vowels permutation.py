class Solution:
    def countVowelPermutation(self, n: int) -> int:
        MODULO = 10**9 + 7
        dp = [1] * 5 # number of string end at character i, with i=[a, e, i, o, u] 
        for _ in range(1, n):
            a, e, i, o, u = dp
            dp[0] = (e + i + u) % MODULO
            dp[1] = (a + i) % MODULO
            dp[2] = (e + o) % MODULO
            dp[3] = i % MODULO
            dp[4] = (i + o) % MODULO
            
        return sum(dp) % MODULO
                
        
#2nd approach by Prateek Goel




class Solution(object):
    def countVowelPermutation(self, n):
        MOD=(10**9)+7
        if n==1:
            return 5
        d={'a':1,'e':2,'i':4,'o':2,'u':1}
        cnt = {'a':1,'e':1,'i':1,'o':1,'u':1}
        s=0
        for k in range(1,n):
            s=0
            temp=defaultdict(int)
            for i,j in cnt.items():
                s+=(j*d[i])
                if i=='a':
                    temp['e']+=j
                elif i=='e':
                    temp['a']+=j
                    temp['i']+=j
                elif i=='i':
                    temp['a']+=j
                    temp['e']+=j
                    temp['o']+=j
                    temp['u']+=j
                elif i=='o':
                    temp['i']+=j
                    temp['u']+=j     
                else:
                    temp['a']+=j
            cnt = temp   
        return s%MOD
class Solution(object):
    def myPow(self, x, nn):
        ans=1.0
        n=nn
        if nn<0:
            n=abs(nn)
        while n>0:
            if n%2:
                ans*=x
                n-=1
            else:
                x*=x
                n//=2
        if nn<0:
            return 1/ans
        return ans
            
        
        
        
        """
        :type x: float
        :type n: int
        :rtype: float
        """
        